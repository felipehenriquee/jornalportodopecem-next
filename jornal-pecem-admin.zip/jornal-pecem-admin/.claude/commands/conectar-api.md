---
description: Liga um recurso do painel à API real
argument-hint: <recurso, ex.: noticias> <URL base opcional>
---
Conecte o recurso $ARGUMENTS à API real.

1. Leia `src/services/http.ts`, `src/services/api.ts` e `docs/API.md`.
2. Confirme comigo o formato real da resposta (peça um exemplo de JSON se eu não tiver passado).
3. Ajuste tipos e o adaptador REST; mantenha o mock funcionando para quando `VITE_API_URL` estiver vazio.
4. Atualize `docs/API.md` e rode `npm run type-check`.
