---
description: Cria uma nova tela do painel seguindo o design system
argument-hint: <nome da tela e o que ela faz>
---
Crie uma nova tela no painel: $ARGUMENTS

1. Leia `CLAUDE.md` e `docs/DESIGN-SYSTEM.md`.
2. Se precisar de dados, adicione tipos em `src/types/index.ts`, mocks em `src/data/mock.ts`, a função em `src/services/api.ts` (mock + REST) e o endpoint em `docs/API.md`.
3. Crie `src/views/<Nome>View.vue` usando `.page`, `PageHeader` e os primitivos de `base.css`. Sem hex soltos.
4. Registre a rota em `src/router/index.ts` (com `meta.titulo`) e o item no menu de `src/layouts/AdminLayout.vue` (ícone lucide; use `auth.pode` se for restrito).
5. Rode `npm run type-check` e corrija tudo.
6. Resuma o que criou e como testar.
