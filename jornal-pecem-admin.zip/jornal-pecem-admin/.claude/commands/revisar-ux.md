---
description: Revisão de UX/UI e acessibilidade de uma tela ou componente
argument-hint: <arquivo ou tela>
---
Faça uma revisão de UX/UI sênior de: $ARGUMENTS

Verifique, citando arquivo e linha:
- Aderência ao `docs/DESIGN-SYSTEM.md` (tokens, tipografia, espaçamento, padrões de tela)
- Hierarquia visual e clareza da ação principal
- Estados: carregando, vazio, erro, sucesso, sem permissão
- Acessibilidade: rótulos, `aria-label` em botões de ícone, foco visível, contraste, navegação por teclado
- Responsivo em 375px e tema escuro
- Textos da interface: claros, em pt-BR, com consequência explicada em ações destrutivas

Liste os problemas por prioridade (alta/média/baixa) e pergunte antes de aplicar as correções.
