# Contrato da API REST

O painel espera uma API JSON em `VITE_API_URL`. Autenticação por
`Authorization: Bearer <token>`. Tipos em `src/types/index.ts`.

| Método | Rota | Corpo / Query | Resposta |
|---|---|---|---|
| POST | `/auth/login` | `{ email, senha }` | `{ token, usuario: Usuario }` |
| GET | `/painel/resumo` | — | `ResumoPainel` (ver `services/api.ts`) |
| GET | `/noticias` | `busca, status, editoriaId, pagina, porPagina` | `Paginado<Noticia>` |
| GET | `/noticias/:id` | — | `Noticia` |
| POST | `/noticias` | `Noticia` sem `id` | `Noticia` |
| PUT | `/noticias/:id` | `Noticia` | `Noticia` |
| DELETE | `/noticias/:id` | — | `204` |
| GET / POST | `/editorias` | — / `Editoria` | `Editoria[]` / `Editoria` |
| PUT / DELETE | `/editorias/:id` | `Editoria` / — | `Editoria` / `204` |
| GET / POST | `/anuncios` | — / `Anuncio` | `Anuncio[]` / `Anuncio` |
| PUT / DELETE | `/anuncios/:id` | `Anuncio` / — | `Anuncio` / `204` |
| GET / POST | `/usuarios` | — / `Usuario` | `Usuario[]` / `Usuario` |
| PUT | `/usuarios/:id` | `Usuario` | `Usuario` |
| GET | `/midias` | — | `Midia[]` |
| POST | `/midias` | multipart `arquivo` (a implementar) | `Midia` |
| DELETE | `/midias/:id` | — | `204` |

Datas em ISO 8601 com fuso (`2026-11-05T09:31:00-03:00`); datas de anúncio em `YYYY-MM-DD`.
Erros: status HTTP adequado e mensagem em texto ou JSON — o painel mostra a mensagem num toast.
