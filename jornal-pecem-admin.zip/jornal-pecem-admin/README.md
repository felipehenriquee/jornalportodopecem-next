# Painel da Redação · Jornal Porto do Pecém

Sistema administrativo (CMS) para o site [jornalportodopecem.com.br](https://jornalportodopecem.com.br/),
com a identidade visual do jornal (marinho `#142248`, petróleo `#009999`, Roboto).

## Como rodar

```bash
npm install
npm run dev
```

Abra http://localhost:5173. Sem `VITE_API_URL` o painel roda em **modo demonstração**:
entre com um e-mail de `src/data/mock.ts` e qualquer senha de 4+ caracteres.

## Telas

- **Painel** — KPIs editoriais, visualizações dos últimos 14 dias, mais lidas, fila da redação
- **Notícias** — abas por status, busca, filtro por editoria, paginação
- **Editor de notícia** — título em serifa, linha fina, texto com barra Markdown, contagem de palavras,
  capa, tags, prévia no estilo do site, SEO com prévia do Google, agendamento e fluxo de revisão
- **Editorias** — árvore espelhando o menu do site (Notícias → Nacionais/Internacionais), cor do rótulo
- **Mídia** — biblioteca com arrastar-e-soltar
- **Anúncios** — espaços "Anuncie aqui", vigência, impressões, cliques e CTR
- **Equipe** — convites e papéis (admin, editor, repórter, colunista, comercial)
- **Configurações** — identidade, home, fluxo editorial, redes, tema
- Tema claro/escuro e layout responsivo

## Usando com o Claude no VS Code

O projeto vem com `CLAUDE.md` (contexto e regras), `docs/DESIGN-SYSTEM.md`, `docs/API.md` e comandos prontos:

- `/nova-tela <descrição>` — cria uma tela nova já no padrão visual
- `/revisar-ux <arquivo>` — revisão de UX/UI e acessibilidade
- `/conectar-api <recurso>` — liga um recurso à API real

## Conectar à API

Copie `.env.example` para `.env` e preencha `VITE_API_URL`. O contrato esperado está em `docs/API.md`.
