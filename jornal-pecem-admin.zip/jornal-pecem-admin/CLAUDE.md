# Painel da Redação — Jornal Porto do Pecém

Painel administrativo (CMS) do site https://jornalportodopecem.com.br/.
Público: editores, repórteres, colunistas e equipe comercial do jornal.
Idioma da interface, do código de domínio e dos commits: **português do Brasil**.

## Stack

- Vue 3 (`<script setup lang="ts">`, Composition API) + TypeScript estrito
- Vite · Vue Router 4 · Pinia (stores no estilo setup) · lucide-vue-next (ícones)
- CSS puro com design tokens (`src/styles/tokens.css`) — **sem** Tailwind/UI kit
- Sem backend ainda: `src/services/api.ts` usa mocks em memória quando `VITE_API_URL` está vazio

## Comandos

```bash
npm install
npm run dev         # http://localhost:5173
npm run type-check  # vue-tsc — rode sempre antes de concluir uma tarefa
npm run build
```

Login no modo demonstração: qualquer e-mail ativo de `src/data/mock.ts` + senha com 4+ caracteres
(ex.: o administrador, o editor ou o repórter — os papéis mudam o que aparece no menu).

## Estrutura

```
src/
  styles/tokens.css      cores, tipografia, espaçamentos (claro + escuro)
  styles/base.css        primitivos: .card .btn .field .input .table .chip .page
  types/index.ts         Noticia, Editoria, Anuncio, Usuario, Midia...
  data/mock.ts           dados de exemplo (editorias = menu real do site)
  services/http.ts       fetch + token; flag usandoMock
  services/api.ts        noticiasApi, editoriasApi, anunciosApi, usuariosApi, midiasApi, authApi
  stores/auth.ts         sessão + pode(acao) — permissões por papel
  stores/ui.ts           tema, toasts (notificar), cache de editorias
  layouts/AdminLayout    sidebar marinho + topbar
  components/ui/         BrandMark, PageHeader, StatusBadge, AppModal, AppToggle, CapaPlaceholder, EmptyState, ToastHost
  views/                 uma view por rota (ver router/index.ts)
```

## Regras de design (obrigatórias)

Leia `docs/DESIGN-SYSTEM.md` antes de criar telas. Resumo:

- **Nunca** escreva hex soltos em componentes — use `var(--token)`. Se faltar cor, crie o token em `tokens.css` (claro **e** escuro).
- Marinho `--navy-900` (#142248) = estrutura (sidebar, botão secundário forte). Petróleo `--accent` (#009999) = ação principal, links, item ativo. Areia `--sand-500` = destaque/estrela, uso pontual.
- Títulos de matéria usam `--font-headline` (Roboto Serif); o resto da UI usa Roboto.
- Toda tela começa com `<div class="page">` + `<PageHeader eyebrow titulo subtitulo>` e ações no slot.
- Ações destrutivas sempre passam por `AppModal` de confirmação, com texto explicando a consequência.
- Feedback de sucesso/erro via `useUiStore().notificar(texto, tipo)`.
- Rótulos de formulário visíveis (`.field > label`); ícone sozinho precisa de `aria-label`.
- Testar em 375px de largura e no tema escuro.

## Regras de código

- Componentes em PascalCase; arquivos de view terminam em `View.vue`.
- Nomes de domínio em português (`noticia`, `editoria`, `salvar`, `remover`); termos técnicos podem ficar em inglês.
- Acesso a dados **só** via `src/services/api.ts`. Ao criar um recurso novo, implemente as duas pontas (mock e REST) e documente o endpoint em `docs/API.md`.
- Permissões novas entram em `pode()` de `stores/auth.ts`; o menu e os botões consultam `auth.pode(...)`.
- Não adicione dependências sem necessidade clara; prefira CSS/SVG próprios (o gráfico do painel é SVG puro).
- `localStorage` sempre dentro de `try/catch`.

## Próximos passos sugeridos

- Ligar à API real (preencher `VITE_API_URL` e validar contratos em `docs/API.md`)
- Upload real de mídia (multipart) e seletor de mídia dentro do editor
- Editor rico (ex.: Tiptap) mantendo a barra atual como referência visual
- Histórico de versões da notícia e comentários de revisão
- Testes com Vitest + Vue Test Utils
