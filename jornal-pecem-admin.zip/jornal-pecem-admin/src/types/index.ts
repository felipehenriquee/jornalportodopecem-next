export type StatusNoticia = 'rascunho' | 'revisao' | 'agendada' | 'publicada' | 'arquivada'

export type Papel = 'admin' | 'editor' | 'reporter' | 'colunista' | 'comercial'

export interface Editoria {
  id: number
  nome: string
  slug: string
  descricao: string
  cor: string
  /** Editoria-mãe (ex.: Nacionais → Notícias) */
  paiId: number | null
  ordemMenu: number
  ativa: boolean
}

export interface Usuario {
  id: number
  nome: string
  email: string
  papel: Papel
  ativo: boolean
  ultimoAcesso: string
}

export interface Noticia {
  id: number
  titulo: string
  linhaFina: string
  slug: string
  corpo: string
  editoriaId: number
  autorId: number
  status: StatusNoticia
  destaque: boolean
  imagemCapa: string
  legendaCapa: string
  creditoCapa: string
  tags: string[]
  seoTitulo: string
  seoDescricao: string
  publicadaEm: string | null
  agendadaPara: string | null
  atualizadaEm: string
  visualizacoes: number
}

export type PosicaoAnuncio = 'topo' | 'lateral' | 'entre-noticias' | 'rodape'

export interface Anuncio {
  id: number
  cliente: string
  titulo: string
  posicao: PosicaoAnuncio
  imagem: string
  link: string
  inicio: string
  fim: string
  ativo: boolean
  impressoes: number
  cliques: number
}

export interface Midia {
  id: number
  nome: string
  url: string
  tipo: 'imagem' | 'pdf'
  tamanhoKb: number
  credito: string
  enviadaEm: string
}

export interface Paginado<T> {
  itens: T[]
  total: number
  pagina: number
  porPagina: number
}

export interface FiltroNoticias {
  busca?: string
  status?: StatusNoticia | ''
  editoriaId?: number | ''
  pagina?: number
  porPagina?: number
}
