/**
 * Dados de exemplo usados enquanto não há API (VITE_API_URL vazio).
 * As editorias espelham o menu real do site público.
 * Usuários e conteúdos são fictícios.
 */
import type { Anuncio, Editoria, Midia, Noticia, Usuario } from '@/types'

export const editorias: Editoria[] = [
  { id: 1, nome: 'Destaques Portuários', slug: 'destaques', descricao: 'Manchetes do complexo portuário', cor: '#009999', paiId: null, ordemMenu: 1, ativa: true },
  { id: 2, nome: 'Notícias', slug: 'noticias', descricao: 'Agrupador de Nacionais e Internacionais', cor: '#142248', paiId: null, ordemMenu: 2, ativa: true },
  { id: 3, nome: 'Nacionais', slug: 'nacionais', descricao: 'Notícias do Brasil', cor: '#2a3f74', paiId: 2, ordemMenu: 1, ativa: true },
  { id: 4, nome: 'Internacionais', slug: 'internacionais', descricao: 'Notícias do mundo', cor: '#1d2f5e', paiId: 2, ordemMenu: 2, ativa: true },
  { id: 5, nome: 'Artigos e Opinião', slug: 'artigos', descricao: 'Colunistas e artigos assinados', cor: '#c9a14a', paiId: null, ordemMenu: 3, ativa: true },
  { id: 6, nome: 'Turismo', slug: 'turismo', descricao: 'Pecém, Caucaia, São Gonçalo e região', cor: '#1fb3b3', paiId: null, ordemMenu: 4, ativa: true },
  { id: 7, nome: 'Comércio Exterior', slug: 'comex', descricao: 'Exportação, importação e câmbio', cor: '#007373', paiId: null, ordemMenu: 5, ativa: true },
  { id: 8, nome: 'Logística e Transporte', slug: 'logistica', descricao: 'Modais, cargas e infraestrutura', cor: '#008585', paiId: null, ordemMenu: 6, ativa: true },
  { id: 9, nome: 'Entrevistas', slug: 'entrevistas', descricao: 'Conversas com lideranças do setor', cor: '#495057', paiId: null, ordemMenu: 7, ativa: true },
  { id: 10, nome: 'Portos do Brasil', slug: 'portos', descricao: 'Outros portos e terminais', cor: '#2a3f74', paiId: null, ordemMenu: 8, ativa: true },
  { id: 11, nome: 'Eventos', slug: 'eventos', descricao: 'Feiras, congressos e agenda', cor: '#b7791f', paiId: null, ordemMenu: 9, ativa: true },
  { id: 12, nome: 'Complexo Portuário', slug: 'complexo', descricao: 'Bloco "Outras notícias" da home', cor: '#142248', paiId: null, ordemMenu: 10, ativa: true },
  { id: 13, nome: 'Caucaia', slug: 'caucaia-saogoncalo', descricao: 'Bloco "Outras notícias" da home', cor: '#1fb3b3', paiId: null, ordemMenu: 11, ativa: true },
  { id: 14, nome: 'São Gonçalo', slug: 'goncalo', descricao: 'Bloco "Outras notícias" da home', cor: '#009999', paiId: null, ordemMenu: 12, ativa: true },
]

export const usuarios: Usuario[] = [
  { id: 1, nome: 'Administrador', email: 'admin@jornalportodopecem.test', papel: 'admin', ativo: true, ultimoAcesso: '2026-11-05T09:40:00-03:00' },
  { id: 2, nome: 'Marina Albuquerque', email: 'marina@jornalportodopecem.test', papel: 'editor', ativo: true, ultimoAcesso: '2026-11-05T08:12:00-03:00' },
  { id: 3, nome: 'Rafael Holanda', email: 'rafael@jornalportodopecem.test', papel: 'reporter', ativo: true, ultimoAcesso: '2026-11-04T17:55:00-03:00' },
  { id: 4, nome: 'Lúcia Bezerra', email: 'lucia@jornalportodopecem.test', papel: 'colunista', ativo: true, ultimoAcesso: '2026-11-02T10:03:00-03:00' },
  { id: 5, nome: 'Tiago Moura', email: 'tiago@jornalportodopecem.test', papel: 'comercial', ativo: true, ultimoAcesso: '2026-11-03T14:20:00-03:00' },
  { id: 6, nome: 'Beatriz Sales', email: 'beatriz@jornalportodopecem.test', papel: 'reporter', ativo: false, ultimoAcesso: '2026-08-21T09:00:00-03:00' },
]

const lorem =
  'O Complexo Industrial e Portuário do Pecém segue ampliando sua participação na movimentação de cargas do Nordeste.\n\nSegundo a administração, as novas frentes de trabalho devem ser concluídas ao longo do próximo ano, com impacto direto sobre a cadeia logística da região metropolitana de Fortaleza.\n\n"Estamos preparando a infraestrutura para a próxima década", afirmou a diretoria em nota.'

function n(p: Partial<Noticia> & Pick<Noticia, 'id' | 'titulo' | 'editoriaId' | 'status'>): Noticia {
  const slug = p.titulo
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
  return {
    linhaFina: '',
    slug,
    corpo: lorem,
    autorId: 3,
    destaque: false,
    imagemCapa: '',
    legendaCapa: '',
    creditoCapa: '',
    tags: [],
    seoTitulo: '',
    seoDescricao: '',
    publicadaEm: null,
    agendadaPara: null,
    atualizadaEm: '2026-11-05T09:00:00-03:00',
    visualizacoes: 0,
    ...p,
  }
}

export const noticias: Noticia[] = [
  n({ id: 52, titulo: 'Pecém recebe maior navio de contêineres já atracado no Ceará', linhaFina: 'Embarcação de 366 metros inaugura nova rota direta com a Ásia', editoriaId: 1, status: 'revisao', autorId: 3, destaque: true, tags: ['contêineres', 'Ásia'], atualizadaEm: '2026-11-05T09:31:00-03:00' }),
  n({ id: 51, titulo: 'Hub de hidrogênio verde: o que muda para os trabalhadores de São Gonçalo', editoriaId: 14, status: 'rascunho', autorId: 3, atualizadaEm: '2026-11-05T08:50:00-03:00' }),
  n({ id: 50, titulo: 'Exportação de frutas pelo Pecém cresce na safra de melão', linhaFina: 'Volume embarcado supera o do mesmo período do ano passado', editoriaId: 7, status: 'agendada', autorId: 2, agendadaPara: '2026-11-06T07:00:00-03:00', tags: ['fruticultura', 'exportação'], atualizadaEm: '2026-11-04T19:10:00-03:00' }),
  n({ id: 49, titulo: 'Entrevista: os próximos dez anos da logística cearense', editoriaId: 9, status: 'publicada', autorId: 2, publicadaEm: '2026-11-04T10:00:00-03:00', visualizacoes: 1840, atualizadaEm: '2026-11-04T10:00:00-03:00' }),
  n({ id: 48, titulo: 'Ferrovia Transnordestina avança no trecho cearense', editoriaId: 8, status: 'publicada', autorId: 3, publicadaEm: '2026-11-03T15:20:00-03:00', visualizacoes: 2390, destaque: true, atualizadaEm: '2026-11-03T15:20:00-03:00' }),
  n({ id: 47, titulo: 'Praias do Pecém e Taíba entram no roteiro de cruzeiros da temporada', editoriaId: 6, status: 'publicada', autorId: 3, publicadaEm: '2026-11-02T09:00:00-03:00', visualizacoes: 3105, atualizadaEm: '2026-11-02T09:00:00-03:00' }),
  n({ id: 46, titulo: 'Porto de Santos registra recorde de movimentação no trimestre', editoriaId: 10, status: 'publicada', autorId: 2, publicadaEm: '2026-11-01T11:30:00-03:00', visualizacoes: 980, atualizadaEm: '2026-11-01T11:30:00-03:00' }),
  n({ id: 45, titulo: 'O porto como vetor de desenvolvimento regional', editoriaId: 5, status: 'publicada', autorId: 4, publicadaEm: '2026-10-31T08:00:00-03:00', visualizacoes: 760, atualizadaEm: '2026-10-31T08:00:00-03:00' }),
  n({ id: 44, titulo: 'Rotterdam e Pecém ampliam cooperação técnica', editoriaId: 4, status: 'publicada', autorId: 2, publicadaEm: '2026-10-30T14:00:00-03:00', visualizacoes: 1422, atualizadaEm: '2026-10-30T14:00:00-03:00' }),
  n({ id: 43, titulo: 'Congresso de logística portuária abre inscrições em Fortaleza', editoriaId: 11, status: 'publicada', autorId: 3, publicadaEm: '2026-10-29T10:00:00-03:00', visualizacoes: 640, atualizadaEm: '2026-10-29T10:00:00-03:00' }),
  n({ id: 42, titulo: 'Governo federal anuncia investimentos em dragagem no Nordeste', editoriaId: 3, status: 'publicada', autorId: 2, publicadaEm: '2026-10-28T16:45:00-03:00', visualizacoes: 1210, atualizadaEm: '2026-10-28T16:45:00-03:00' }),
  n({ id: 41, titulo: 'Caucaia prepara feira de empreendedorismo no litoral', editoriaId: 13, status: 'arquivada', autorId: 6, publicadaEm: '2026-09-12T10:00:00-03:00', visualizacoes: 305, atualizadaEm: '2026-10-01T10:00:00-03:00' }),
]

export const anuncios: Anuncio[] = [
  { id: 1, cliente: 'Terminal Atlântico Log', titulo: 'Banner institucional', posicao: 'topo', imagem: '', link: 'https://example.com', inicio: '2026-10-01', fim: '2026-12-31', ativo: true, impressoes: 48210, cliques: 612 },
  { id: 2, cliente: 'Despachante Mar Aberto', titulo: 'Desembaraço aduaneiro', posicao: 'lateral', imagem: '', link: 'https://example.com', inicio: '2026-10-15', fim: '2026-11-15', ativo: true, impressoes: 21007, cliques: 288 },
  { id: 3, cliente: 'Pousada Brisa do Pecém', titulo: 'Temporada de verão', posicao: 'entre-noticias', imagem: '', link: 'https://example.com', inicio: '2026-11-10', fim: '2027-02-28', ativo: true, impressoes: 0, cliques: 0 },
  { id: 4, cliente: 'Congresso Logística NE', titulo: 'Inscrições abertas', posicao: 'rodape', imagem: '', link: 'https://example.com', inicio: '2026-08-01', fim: '2026-10-30', ativo: false, impressoes: 30544, cliques: 401 },
]

export const midias: Midia[] = Array.from({ length: 12 }, (_, i) => ({
  id: i + 1,
  nome: ['navio-atracado', 'guindastes-terminal', 'praia-taiba', 'patio-conteineres', 'entrevista-estudio', 'ferrovia-trecho', 'feira-caucaia', 'carga-frutas', 'por-do-sol-pecem', 'reuniao-diretoria', 'dragagem', 'mapa-rotas'][i] + '.jpg',
  url: '',
  tipo: 'imagem' as const,
  tamanhoKb: 180 + i * 37,
  credito: i % 3 === 0 ? 'Divulgação' : 'Redação JPP',
  enviadaEm: `2026-11-0${(i % 5) + 1}T10:00:00-03:00`,
}))

/** Série de visualizações dos últimos 14 dias para o painel */
export const visualizacoesDiarias = [
  3120, 2980, 3410, 3890, 3560, 2210, 1980, 3340, 3720, 4105, 3980, 4420, 2650, 2410,
]
