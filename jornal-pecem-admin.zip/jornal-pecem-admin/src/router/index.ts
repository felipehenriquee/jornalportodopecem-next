import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import AdminLayout from '@/layouts/AdminLayout.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', name: 'login', component: () => import('@/views/LoginView.vue'), meta: { publica: true } },
    {
      path: '/',
      component: AdminLayout,
      children: [
        { path: '', name: 'painel', component: () => import('@/views/DashboardView.vue'), meta: { titulo: 'Painel' } },
        { path: 'noticias', name: 'noticias', component: () => import('@/views/NoticiasView.vue'), meta: { titulo: 'Notícias' } },
        { path: 'noticias/nova', name: 'noticia-nova', component: () => import('@/views/NoticiaEditorView.vue'), meta: { titulo: 'Nova notícia' } },
        { path: 'noticias/:id', name: 'noticia-editar', component: () => import('@/views/NoticiaEditorView.vue'), meta: { titulo: 'Editar notícia' }, props: true },
        { path: 'editorias', name: 'editorias', component: () => import('@/views/EditoriasView.vue'), meta: { titulo: 'Editorias' } },
        { path: 'midia', name: 'midia', component: () => import('@/views/MidiaView.vue'), meta: { titulo: 'Biblioteca de mídia' } },
        { path: 'anuncios', name: 'anuncios', component: () => import('@/views/AnunciosView.vue'), meta: { titulo: 'Anúncios' } },
        { path: 'usuarios', name: 'usuarios', component: () => import('@/views/UsuariosView.vue'), meta: { titulo: 'Equipe' } },
        { path: 'configuracoes', name: 'configuracoes', component: () => import('@/views/ConfiguracoesView.vue'), meta: { titulo: 'Configurações' } },
      ],
    },
    { path: '/:pathMatch(.*)*', redirect: '/' },
  ],
})

router.beforeEach((to) => {
  const auth = useAuthStore()
  if (!to.meta.publica && !auth.logado) return { name: 'login', query: { volta: to.fullPath } }
  if (to.name === 'login' && auth.logado) return { name: 'painel' }
})

router.afterEach((to) => {
  document.title = `${(to.meta.titulo as string) ?? 'Entrar'} · Redação JPP`
})

export default router
