import type { Papel, PosicaoAnuncio, StatusNoticia } from '@/types'

const dataHora = new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
const data = new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })
const numero = new Intl.NumberFormat('pt-BR')

export const fmtDataHora = (iso: string | null) => (iso ? dataHora.format(new Date(iso)).replace('.', '') : '—')
export const fmtData = (iso: string | null) => (iso ? data.format(new Date(iso.length === 10 ? iso + 'T12:00:00' : iso)).replace('.', '') : '—')
export const fmtNum = (n: number) => numero.format(n)

export function tempoRelativo(iso: string): string {
  const min = Math.round((Date.now() - new Date(iso).getTime()) / 60000)
  if (min < 1) return 'agora'
  if (min < 60) return `há ${min} min`
  const h = Math.round(min / 60)
  if (h < 24) return `há ${h} h`
  const d = Math.round(h / 24)
  return d === 1 ? 'ontem' : `há ${d} dias`
}

export function slugify(t: string) {
  return t
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

export const statusLabel: Record<StatusNoticia, string> = {
  rascunho: 'Rascunho',
  revisao: 'Em revisão',
  agendada: 'Agendada',
  publicada: 'Publicada',
  arquivada: 'Arquivada',
}

export const papelLabel: Record<Papel, string> = {
  admin: 'Administrador',
  editor: 'Editor-chefe',
  reporter: 'Repórter',
  colunista: 'Colunista',
  comercial: 'Comercial',
}

export const posicaoLabel: Record<PosicaoAnuncio, string> = {
  topo: 'Topo (728×90)',
  lateral: 'Lateral (300×250)',
  'entre-noticias': 'Entre notícias (728×90)',
  rodape: 'Rodapé (970×90)',
}

export const iniciais = (nome: string) =>
  nome
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join('')
