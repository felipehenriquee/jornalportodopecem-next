<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { LogIn } from 'lucide-vue-next'
import BrandMark from '@/components/ui/BrandMark.vue'
import { useAuthStore } from '@/stores/auth'
import { usandoMock } from '@/services/http'

const auth = useAuthStore()
const router = useRouter()
const route = useRoute()

const email = ref('')
const senha = ref('')
const erro = ref('')
const enviando = ref(false)

async function entrar() {
  erro.value = ''
  enviando.value = true
  try {
    await auth.entrar(email.value, senha.value)
    router.replace((route.query.volta as string) || '/')
  } catch (e) {
    erro.value = (e as Error).message
  } finally {
    enviando.value = false
  }
}
</script>

<template>
  <div class="login">
    <section class="arte" aria-hidden="true">
      <div class="ondas" />
      <BrandMark claro :tamanho="64" />
      <div class="frase">
        <p class="eyebrow">Painel da Redação</p>
        <h1>A notícia do porto, do Ceará para o mundo.</h1>
      </div>
      <p class="rodape">Jornal Porto do Pecém · São Gonçalo do Amarante, CE</p>
    </section>

    <section class="form-lado">
      <form class="card form" @submit.prevent="entrar">
        <div>
          <h2>Entrar</h2>
          <p class="muted">Acesse com seu e-mail da redação.</p>
        </div>

        <div class="field">
          <label for="email">E-mail</label>
          <input id="email" v-model="email" class="input" type="email" autocomplete="username" required />
        </div>
        <div class="field">
          <label for="senha">Senha</label>
          <input id="senha" v-model="senha" class="input" type="password" autocomplete="current-password" required />
        </div>

        <p v-if="erro" class="erro" role="alert">{{ erro }}</p>

        <button class="btn btn-primary entrar" :disabled="enviando">
          <LogIn /> {{ enviando ? 'Entrando…' : 'Entrar' }}
        </button>

        <p v-if="usandoMock" class="demo">
          Modo demonstração: use um e-mail de <code>src/data/mock.ts</code> e qualquer senha com 4+ caracteres.
        </p>
      </form>
    </section>
  </div>
</template>

<style scoped>
.login {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1.1fr 1fr;
}

.arte {
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 48px;
  background: radial-gradient(120% 90% at 0% 100%, rgba(0, 153, 153, 0.45), transparent 60%), var(--navy-900);
  color: #fff;
}

/* Linhas de navegação / ondas sutis */
.ondas {
  position: absolute;
  inset: 0;
  background: repeating-radial-gradient(circle at 85% 20%, transparent 0 38px, rgba(255, 255, 255, 0.045) 38px 39px);
  pointer-events: none;
}

.frase {
  position: relative;
  max-width: 460px;
}

.frase .eyebrow {
  color: var(--teal-400);
}

.frase h1 {
  font-family: var(--font-headline);
  font-size: 2.4rem;
  font-weight: 700;
  line-height: 1.15;
  margin-top: 12px;
}

.rodape {
  position: relative;
  margin: 0;
  font-size: var(--fs-xs);
  opacity: 0.6;
}

.form-lado {
  display: grid;
  place-items: center;
  padding: 32px 20px;
}

.form {
  width: 100%;
  max-width: 380px;
  padding: 32px;
  display: grid;
  gap: 18px;
  box-shadow: var(--shadow);
}

.form h2 {
  font-size: var(--fs-xl);
}

.form p {
  margin: 4px 0 0;
}

.entrar {
  height: 44px;
  font-size: var(--fs-md);
}

.erro {
  margin: 0;
  padding: 10px 12px;
  border-radius: var(--radius-sm);
  background: var(--danger-100);
  color: var(--danger-600);
  font-size: var(--fs-sm);
}

.demo {
  font-size: var(--fs-xs);
  color: var(--text-muted);
  padding: 10px 12px;
  border-radius: var(--radius-sm);
  background: var(--surface-sunken);
}

.demo code {
  font-family: var(--font-mono);
  font-size: 0.7rem;
}

@media (max-width: 860px) {
  .login {
    grid-template-columns: 1fr;
  }
  .arte {
    padding: 28px;
    min-height: 220px;
  }
  .frase h1 {
    font-size: 1.6rem;
  }
}
</style>
