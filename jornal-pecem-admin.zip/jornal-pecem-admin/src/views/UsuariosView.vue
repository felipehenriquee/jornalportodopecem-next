<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { UserPlus, Pencil } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import AppModal from '@/components/ui/AppModal.vue'
import AppToggle from '@/components/ui/AppToggle.vue'
import { usuariosApi } from '@/services/api'
import { useUiStore } from '@/stores/ui'
import type { Papel, Usuario } from '@/types'
import { iniciais, papelLabel, tempoRelativo } from '@/utils/format'

const ui = useUiStore()
const itens = ref<Usuario[]>([])
const edicao = ref<Usuario | null>(null)
const papeis = Object.keys(papelLabel) as Papel[]

const descricaoPapel: Record<Papel, string> = {
  admin: 'Acesso total, incluindo equipe e configurações',
  editor: 'Revisa, publica e organiza editorias',
  reporter: 'Escreve e envia matérias para revisão',
  colunista: 'Escreve artigos de opinião para revisão',
  comercial: 'Gerencia anúncios e relatórios comerciais',
}

onMounted(async () => (itens.value = await usuariosApi.listar()))

function novo() {
  edicao.value = { id: 0, nome: '', email: '', papel: 'reporter', ativo: true, ultimoAcesso: '' }
}

async function salvar() {
  const u = edicao.value!
  if (!u.nome.trim() || !/^\S+@\S+\.\S+$/.test(u.email)) {
    ui.notificar('Preencha nome e um e-mail válido', 'erro')
    return
  }
  const salvo = await usuariosApi.salvar(u.id ? u : { ...u, id: undefined })
  itens.value = u.id ? itens.value.map((x) => (x.id === u.id ? salvo : x)) : [salvo, ...itens.value]
  ui.notificar(u.id ? 'Dados atualizados' : 'Convite enviado')
  edicao.value = null
}
</script>

<template>
  <div class="page">
    <PageHeader eyebrow="Gestão" titulo="Equipe" subtitulo="Quem tem acesso ao painel e o que cada um pode fazer.">
      <button class="btn btn-primary" @click="novo"><UserPlus /> Convidar pessoa</button>
    </PageHeader>

    <section class="card">
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Pessoa</th><th>Papel</th><th>Último acesso</th><th>Status</th><th><span class="sr-only">Ações</span></th></tr></thead>
          <tbody>
            <tr v-for="u in itens" :key="u.id">
              <td>
                <div class="pessoa">
                  <span class="av" :class="u.papel">{{ iniciais(u.nome) }}</span>
                  <div><strong>{{ u.nome }}</strong><span class="muted">{{ u.email }}</span></div>
                </div>
              </td>
              <td><span class="chip">{{ papelLabel[u.papel] }}</span></td>
              <td class="muted">{{ u.ultimoAcesso ? tempoRelativo(u.ultimoAcesso) : 'Convite pendente' }}</td>
              <td><span :class="u.ativo ? 'ativo' : 'muted'">{{ u.ativo ? 'Ativo' : 'Desativado' }}</span></td>
              <td><button class="btn btn-ghost btn-icon" aria-label="Editar" @click="edicao = { ...u }"><Pencil /></button></td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <AppModal v-if="edicao" :titulo="edicao.id ? 'Editar acesso' : 'Convidar pessoa'" @fechar="edicao = null">
      <div class="field"><label for="un">Nome</label><input id="un" v-model="edicao.nome" class="input" /></div>
      <div class="field"><label for="ue">E-mail</label><input id="ue" v-model="edicao.email" type="email" class="input" /></div>
      <fieldset class="papeis">
        <legend>Papel</legend>
        <label v-for="p in papeis" :key="p" class="papel" :class="{ sel: edicao.papel === p }">
          <input v-model="edicao.papel" type="radio" :value="p" class="sr-only" />
          <strong>{{ papelLabel[p] }}</strong>
          <span class="muted">{{ descricaoPapel[p] }}</span>
        </label>
      </fieldset>
      <AppToggle v-if="edicao.id" v-model="edicao.ativo" rotulo="Acesso ativo" />
      <template #rodape>
        <button class="btn btn-ghost" @click="edicao = null">Cancelar</button>
        <button class="btn btn-primary" @click="salvar">{{ edicao.id ? 'Salvar' : 'Enviar convite' }}</button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.pessoa {
  display: flex;
  align-items: center;
  gap: 12px;
}
.pessoa div {
  display: flex;
  flex-direction: column;
  line-height: 1.3;
}
.pessoa .muted {
  font-size: var(--fs-xs);
}
.av {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  font-size: var(--fs-xs);
  font-weight: 700;
  color: #fff;
  background: var(--navy-700);
  flex: none;
}
.av.admin { background: var(--navy-900); }
.av.editor { background: var(--teal-600); }
.av.colunista { background: var(--sand-500); }
.av.comercial { background: var(--ink-700); }
.ativo {
  color: var(--success-600);
  font-weight: 500;
}
.papeis {
  border: 0;
  padding: 0;
  margin: 0;
  display: grid;
  gap: 8px;
}
legend {
  font-size: var(--fs-sm);
  font-weight: 500;
  color: var(--text-soft);
  margin-bottom: 6px;
}
.papel {
  display: flex;
  flex-direction: column;
  padding: 10px 12px;
  border: 1px solid var(--border-strong);
  border-radius: var(--radius-sm);
  cursor: pointer;
  font-size: var(--fs-sm);
}
.papel span {
  font-size: var(--fs-xs);
}
.papel.sel {
  border-color: var(--accent);
  background: var(--accent-soft);
}
.papel:has(input:focus-visible) {
  box-shadow: var(--focus);
}
</style>
