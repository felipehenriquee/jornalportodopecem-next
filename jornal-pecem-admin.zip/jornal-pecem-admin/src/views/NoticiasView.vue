<script setup lang="ts">
import { onMounted, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Plus, Search, Pencil, Trash2, Star, ChevronLeft, ChevronRight } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import CapaPlaceholder from '@/components/ui/CapaPlaceholder.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import AppModal from '@/components/ui/AppModal.vue'
import { noticiasApi } from '@/services/api'
import { useUiStore } from '@/stores/ui'
import type { FiltroNoticias, Noticia, Paginado, StatusNoticia } from '@/types'
import { fmtDataHora, fmtNum, statusLabel } from '@/utils/format'

const ui = useUiStore()
const route = useRoute()
const router = useRouter()

const filtro = reactive<Required<FiltroNoticias>>({
  busca: '',
  status: (route.query.status as StatusNoticia) ?? '',
  editoriaId: route.query.editoria ? Number(route.query.editoria) : '',
  pagina: 1,
  porPagina: 10,
})

const dados = ref<Paginado<Noticia> | null>(null)
const carregando = ref(false)
const excluir = ref<Noticia | null>(null)

async function carregar() {
  carregando.value = true
  try {
    dados.value = await noticiasApi.listar(filtro)
  } finally {
    carregando.value = false
  }
}

let timer: ReturnType<typeof setTimeout>
watch(
  () => filtro.busca,
  () => {
    clearTimeout(timer)
    timer = setTimeout(() => {
      filtro.pagina = 1
      carregar()
    }, 300)
  },
)
watch(
  () => [filtro.status, filtro.editoriaId],
  () => {
    filtro.pagina = 1
    router.replace({ query: { ...(filtro.status && { status: filtro.status }), ...(filtro.editoriaId && { editoria: filtro.editoriaId }) } })
    carregar()
  },
)
watch(() => filtro.pagina, carregar)
onMounted(carregar)

const abas: { valor: StatusNoticia | ''; rotulo: string }[] = [
  { valor: '', rotulo: 'Todas' },
  ...(['publicada', 'revisao', 'agendada', 'rascunho', 'arquivada'] as StatusNoticia[]).map((s) => ({ valor: s, rotulo: statusLabel[s] })),
]

const totalPaginas = () => (dados.value ? Math.max(1, Math.ceil(dados.value.total / dados.value.porPagina)) : 1)

async function confirmarExclusao() {
  if (!excluir.value) return
  await noticiasApi.remover(excluir.value.id)
  ui.notificar('Notícia excluída')
  excluir.value = null
  carregar()
}
</script>

<template>
  <div class="page">
    <PageHeader eyebrow="Conteúdo" titulo="Notícias" subtitulo="Tudo o que a redação produziu, do rascunho ao arquivo.">
      <RouterLink to="/noticias/nova" class="btn btn-primary"><Plus /> Nova notícia</RouterLink>
    </PageHeader>

    <section class="card">
      <div class="abas" role="tablist">
        <button
          v-for="a in abas"
          :key="a.valor"
          role="tab"
          :aria-selected="filtro.status === a.valor"
          class="aba"
          :class="{ ativa: filtro.status === a.valor }"
          @click="filtro.status = a.valor"
        >
          {{ a.rotulo }}
        </button>
      </div>

      <div class="filtros">
        <label class="busca">
          <Search :size="16" />
          <span class="sr-only">Buscar</span>
          <input v-model="filtro.busca" class="input" placeholder="Buscar por título ou tag…" />
        </label>
        <select v-model="filtro.editoriaId" class="select" aria-label="Filtrar por editoria">
          <option value="">Todas as editorias</option>
          <option v-for="e in ui.editorias" :key="e.id" :value="e.id">{{ e.nome }}</option>
        </select>
      </div>

      <div class="table-wrap" :class="{ carregando }">
        <table class="table">
          <thead>
            <tr>
              <th style="width: 46%">Notícia</th>
              <th>Editoria</th>
              <th>Status</th>
              <th>Data</th>
              <th class="num">Leituras</th>
              <th><span class="sr-only">Ações</span></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="n in dados?.itens ?? []" :key="n.id">
              <td>
                <div class="noticia">
                  <CapaPlaceholder class="thumb" :url="n.imagemCapa" :cor="ui.corEditoria(n.editoriaId)" />
                  <div class="txt">
                    <RouterLink :to="`/noticias/${n.id}`" class="titulo">
                      <Star v-if="n.destaque" :size="14" class="estrela" aria-label="Destaque" />
                      {{ n.titulo }}
                    </RouterLink>
                    <span v-if="n.linhaFina" class="muted fina">{{ n.linhaFina }}</span>
                  </div>
                </div>
              </td>
              <td>
                <span class="editoria" :style="{ '--c': ui.corEditoria(n.editoriaId) }">{{ ui.nomeEditoria(n.editoriaId) }}</span>
              </td>
              <td><StatusBadge :status="n.status" /></td>
              <td class="muted nowrap">
                {{ fmtDataHora(n.status === 'agendada' ? n.agendadaPara : n.publicadaEm ?? n.atualizadaEm) }}
              </td>
              <td class="num">{{ n.visualizacoes ? fmtNum(n.visualizacoes) : '—' }}</td>
              <td>
                <div class="acoes">
                  <RouterLink :to="`/noticias/${n.id}`" class="btn btn-ghost btn-icon" aria-label="Editar"><Pencil /></RouterLink>
                  <button class="btn btn-danger btn-icon" aria-label="Excluir" @click="excluir = n"><Trash2 /></button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <EmptyState v-if="dados && !dados.itens.length" titulo="Nenhuma notícia encontrada" texto="Ajuste os filtros ou crie uma nova notícia.">
          <RouterLink to="/noticias/nova" class="btn btn-primary"><Plus /> Nova notícia</RouterLink>
        </EmptyState>
      </div>

      <footer v-if="dados && dados.total > 0" class="paginacao">
        <span class="muted">{{ dados.total }} notícia{{ dados.total === 1 ? '' : 's' }}</span>
        <div class="pag">
          <button class="btn btn-ghost btn-icon" :disabled="filtro.pagina <= 1" aria-label="Anterior" @click="filtro.pagina--"><ChevronLeft /></button>
          <span>{{ filtro.pagina }} / {{ totalPaginas() }}</span>
          <button class="btn btn-ghost btn-icon" :disabled="filtro.pagina >= totalPaginas()" aria-label="Próxima" @click="filtro.pagina++"><ChevronRight /></button>
        </div>
      </footer>
    </section>

    <AppModal v-if="excluir" titulo="Excluir notícia?" @fechar="excluir = null">
      <p style="margin: 0">
        <strong>{{ excluir.titulo }}</strong> será removida do site e do painel. Para tirar do ar sem apagar, prefira
        <em>Arquivar</em> no editor.
      </p>
      <template #rodape>
        <button class="btn btn-ghost" @click="excluir = null">Cancelar</button>
        <button class="btn btn-primary" style="background: var(--danger-600)" @click="confirmarExclusao">Excluir</button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.abas {
  display: flex;
  gap: 2px;
  padding: 0 var(--sp-4);
  border-bottom: 1px solid var(--border);
  overflow-x: auto;
}

.aba {
  position: relative;
  border: 0;
  background: none;
  padding: 14px 14px;
  font-size: var(--fs-sm);
  font-weight: 500;
  color: var(--text-muted);
  cursor: pointer;
  white-space: nowrap;
}

.aba:hover {
  color: var(--text);
}

.aba.ativa {
  color: var(--accent);
}

.aba.ativa::after {
  content: '';
  position: absolute;
  left: 10px;
  right: 10px;
  bottom: -1px;
  height: 2px;
  border-radius: 2px;
  background: var(--accent);
}

.filtros {
  display: flex;
  gap: var(--sp-3);
  padding: var(--sp-4);
  flex-wrap: wrap;
}

.busca {
  position: relative;
  flex: 1;
  min-width: 220px;
}

.busca svg {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--text-muted);
}

.busca .input {
  padding-left: 36px;
}

.filtros .select {
  width: auto;
  min-width: 200px;
}

.carregando {
  opacity: 0.55;
  transition: opacity 0.15s;
}

.noticia {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
}

.thumb {
  width: 64px;
  flex: none;
}

.txt {
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.titulo {
  color: var(--text);
  font-weight: 500;
  line-height: 1.35;
}

.titulo:hover {
  color: var(--accent);
}

.estrela {
  color: var(--sand-500);
  fill: var(--sand-500);
  vertical-align: -2px;
}

.fina {
  font-size: var(--fs-xs);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.editoria {
  font-size: var(--fs-xs);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: var(--c);
  white-space: nowrap;
}

:root[data-theme='dark'] .editoria {
  filter: brightness(1.6);
}

.nowrap {
  white-space: nowrap;
}

.num {
  text-align: right;
  font-variant-numeric: tabular-nums;
}

.acoes {
  display: flex;
  gap: 6px;
  justify-content: flex-end;
}

.paginacao {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--sp-3) var(--sp-4);
  font-size: var(--fs-sm);
}

.pag {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
}
</style>
