<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { onBeforeRouteLeave, useRouter } from 'vue-router'
import { ArrowLeft, Bold, Italic, Heading2, Quote, Link2, List, Send, Save, Eye, Archive, X } from 'lucide-vue-next'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import CapaPlaceholder from '@/components/ui/CapaPlaceholder.vue'
import AppToggle from '@/components/ui/AppToggle.vue'
import AppModal from '@/components/ui/AppModal.vue'
import { noticiasApi } from '@/services/api'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import type { Noticia, StatusNoticia } from '@/types'
import { fmtDataHora, slugify } from '@/utils/format'

const props = defineProps<{ id?: string }>()
const auth = useAuthStore()
const ui = useUiStore()
const router = useRouter()

const vazia = (): Noticia => ({
  id: 0,
  titulo: '',
  linhaFina: '',
  slug: '',
  corpo: '',
  editoriaId: 0,
  autorId: auth.usuario?.id ?? 0,
  status: 'rascunho',
  destaque: false,
  imagemCapa: '',
  legendaCapa: '',
  creditoCapa: '',
  tags: [],
  seoTitulo: '',
  seoDescricao: '',
  publicadaEm: null,
  agendadaPara: null,
  atualizadaEm: new Date().toISOString(),
  visualizacoes: 0,
})

const n = ref<Noticia>(vazia())
const original = ref('')
const salvando = ref(false)
const slugManual = ref(false)
const novaTag = ref('')
const previa = ref(false)
const erros = ref<Record<string, string>>({})
const corpoEl = ref<HTMLTextAreaElement>()

onMounted(async () => {
  await ui.carregarEditorias()
  if (props.id) {
    n.value = await noticiasApi.obter(Number(props.id))
    slugManual.value = true
  } else {
    n.value.editoriaId = ui.editorias[0]?.id ?? 0
  }
  original.value = JSON.stringify(n.value)
})

const sujo = computed(() => original.value !== '' && JSON.stringify(n.value) !== original.value)

watch(
  () => n.value.titulo,
  (t) => {
    if (!slugManual.value) n.value.slug = slugify(t)
  },
)

onBeforeRouteLeave(() => {
  if (sujo.value && !salvando.value) return window.confirm('Há alterações não salvas. Sair mesmo assim?')
})

/* ---- Métricas de texto ---- */
const palavras = computed(() => n.value.corpo.trim().split(/\s+/).filter(Boolean).length)
const leitura = computed(() => Math.max(1, Math.round(palavras.value / 200)))

/* ---- Barra de formatação (Markdown) ---- */
function envolver(antes: string, depois = antes, porLinha = false) {
  const el = corpoEl.value
  if (!el) return
  const { selectionStart: a, selectionEnd: b, value } = el
  const sel = value.slice(a, b) || 'texto'
  const novo = porLinha ? sel.split('\n').map((l) => antes + l).join('\n') : antes + sel + depois
  n.value.corpo = value.slice(0, a) + novo + value.slice(b)
  requestAnimationFrame(() => {
    el.focus()
    el.setSelectionRange(a + (porLinha ? 0 : antes.length), a + novo.length - (porLinha ? 0 : depois.length))
  })
}

const ferramentas = [
  { icone: Bold, rotulo: 'Negrito', acao: () => envolver('**') },
  { icone: Italic, rotulo: 'Itálico', acao: () => envolver('_') },
  { icone: Heading2, rotulo: 'Intertítulo', acao: () => envolver('## ', '', true) },
  { icone: Quote, rotulo: 'Citação', acao: () => envolver('> ', '', true) },
  { icone: List, rotulo: 'Lista', acao: () => envolver('- ', '', true) },
  { icone: Link2, rotulo: 'Link', acao: () => envolver('[', '](https://)') },
]

/* Renderização simples para a prévia — troque por um parser (ex.: markdown-it) se precisar */
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
const corpoHtml = computed(() =>
  n.value.corpo
    .split(/\n{2,}/)
    .map((bloco) => {
      let b = esc(bloco.trim())
      b = b.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/_(.+?)_/g, '<em>$1</em>').replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2">$1</a>')
      if (b.startsWith('## ')) return `<h2>${b.slice(3)}</h2>`
      if (b.startsWith('&gt; ')) return `<blockquote>${b.replace(/^&gt; /gm, '')}</blockquote>`
      if (b.startsWith('- ')) return `<ul>${b.split('\n').map((l) => `<li>${l.replace(/^- /, '')}</li>`).join('')}</ul>`
      return b ? `<p>${b.replace(/\n/g, '<br>')}</p>` : ''
    })
    .join(''),
)

/* ---- Tags ---- */
function addTag() {
  const t = novaTag.value.trim().toLowerCase()
  if (t && !n.value.tags.includes(t)) n.value.tags.push(t)
  novaTag.value = ''
}

/* ---- SEO ---- */
const seoTitulo = computed(() => n.value.seoTitulo || n.value.titulo || 'Título da notícia')
const seoDesc = computed(() => n.value.seoDescricao || n.value.linhaFina || n.value.corpo.slice(0, 155))

/* ---- Salvar ---- */
function validar(status: StatusNoticia) {
  const e: Record<string, string> = {}
  if (!n.value.titulo.trim()) e.titulo = 'Informe o título'
  if (!n.value.editoriaId) e.editoria = 'Escolha a editoria'
  if (status !== 'rascunho' && n.value.corpo.trim().length < 50) e.corpo = 'O texto está curto demais para revisão/publicação'
  if (status === 'agendada' && !n.value.agendadaPara) e.agendada = 'Defina data e hora'
  erros.value = e
  return !Object.keys(e).length
}

async function salvar(status: StatusNoticia) {
  if (!validar(status)) {
    ui.notificar('Revise os campos destacados', 'erro')
    return
  }
  salvando.value = true
  try {
    const salva = await noticiasApi.salvar({ ...n.value, status })
    n.value = salva
    original.value = JSON.stringify(salva)
    const msg: Record<StatusNoticia, string> = {
      rascunho: 'Rascunho salvo',
      revisao: 'Enviada para revisão',
      agendada: `Agendada para ${fmtDataHora(salva.agendadaPara)}`,
      publicada: 'Notícia publicada',
      arquivada: 'Notícia arquivada',
    }
    ui.notificar(msg[status])
    if (!props.id) router.replace(`/noticias/${salva.id}`)
  } catch (e) {
    ui.notificar((e as Error).message, 'erro')
  } finally {
    salvando.value = false
  }
}

const podePublicar = computed(() => auth.pode('publicar'))
const agendando = computed({
  get: () => !!n.value.agendadaPara,
  set: (v) => {
    n.value.agendadaPara = v ? n.value.agendadaPara ?? new Date(Date.now() + 36e5).toISOString().slice(0, 16) : null
  },
})
const dataAgenda = computed({
  get: () => (n.value.agendadaPara ? n.value.agendadaPara.slice(0, 16) : ''),
  set: (v: string) => (n.value.agendadaPara = v || null),
})
</script>

<template>
  <div class="editor">
    <!-- Barra de ações fixa -->
    <div class="acoes-barra">
      <RouterLink to="/noticias" class="btn btn-ghost btn-icon" aria-label="Voltar"><ArrowLeft /></RouterLink>
      <div class="estado">
        <StatusBadge :status="n.status" />
        <span class="muted">{{ sujo ? 'Alterações não salvas' : n.id ? `Salvo ${fmtDataHora(n.atualizadaEm)}` : 'Nova notícia' }}</span>
      </div>
      <button class="btn btn-ghost" @click="previa = true"><Eye /> Prévia</button>
      <button class="btn btn-ghost" :disabled="salvando" @click="salvar('rascunho')"><Save /> Salvar rascunho</button>
      <template v-if="podePublicar">
        <button v-if="agendando" class="btn btn-navy" :disabled="salvando" @click="salvar('agendada')">Agendar</button>
        <button v-else class="btn btn-primary" :disabled="salvando" @click="salvar('publicada')"><Send /> Publicar</button>
      </template>
      <button v-else class="btn btn-primary" :disabled="salvando" @click="salvar('revisao')"><Send /> Enviar para revisão</button>
    </div>

    <div class="layout">
      <!-- Coluna de texto -->
      <section class="texto">
        <div class="field">
          <label for="titulo" class="sr-only">Título</label>
          <textarea
            id="titulo"
            v-model="n.titulo"
            class="titulo"
            :class="{ invalido: erros.titulo }"
            rows="2"
            placeholder="Título da notícia"
            maxlength="140"
          />
          <span v-if="erros.titulo" class="msg-erro">{{ erros.titulo }}</span>
          <span class="contador" :class="{ alerta: n.titulo.length > 90 }">{{ n.titulo.length }}/140 · ideal até 90</span>
        </div>

        <div class="field">
          <label for="fina" class="sr-only">Linha fina</label>
          <textarea id="fina" v-model="n.linhaFina" class="fina" rows="2" placeholder="Linha fina — o resumo que aparece abaixo do título" maxlength="220" />
        </div>

        <div class="corpo-box" :class="{ invalido: erros.corpo }">
          <div class="toolbar" role="toolbar" aria-label="Formatação">
            <button v-for="f in ferramentas" :key="f.rotulo" type="button" :title="f.rotulo" :aria-label="f.rotulo" @click="f.acao">
              <component :is="f.icone" :size="16" />
            </button>
            <span class="muted metricas">{{ palavras }} palavras · {{ leitura }} min de leitura</span>
          </div>
          <textarea ref="corpoEl" v-model="n.corpo" class="corpo" placeholder="Escreva a matéria… (aceita Markdown: **negrito**, _itálico_, ## intertítulo, > citação)" />
        </div>
        <span v-if="erros.corpo" class="msg-erro">{{ erros.corpo }}</span>
      </section>

      <!-- Coluna lateral -->
      <aside class="lateral">
        <section class="card bloco">
          <h3>Publicação</h3>
          <div class="field">
            <label for="editoria">Editoria</label>
            <select id="editoria" v-model.number="n.editoriaId" class="select" :class="{ invalido: erros.editoria }">
              <option :value="0" disabled>Selecione…</option>
              <option v-for="e in ui.editorias.filter((e) => e.ativa)" :key="e.id" :value="e.id">
                {{ e.paiId ? '— ' : '' }}{{ e.nome }}
              </option>
            </select>
            <span v-if="erros.editoria" class="msg-erro">{{ erros.editoria }}</span>
          </div>
          <AppToggle v-model="n.destaque" rotulo="Destaque na home" />
          <template v-if="podePublicar">
            <AppToggle v-model="agendando" rotulo="Agendar publicação" />
            <div v-if="agendando" class="field">
              <label for="agenda">Data e hora</label>
              <input id="agenda" v-model="dataAgenda" type="datetime-local" class="input" :class="{ invalido: erros.agendada }" />
            </div>
          </template>
          <button v-if="n.id && n.status === 'publicada' && podePublicar" class="btn btn-ghost" @click="salvar('arquivada')">
            <Archive /> Arquivar
          </button>
        </section>

        <section class="card bloco">
          <h3>Imagem de capa</h3>
          <CapaPlaceholder :url="n.imagemCapa" :cor="ui.corEditoria(n.editoriaId)" :alt="n.legendaCapa" />
          <div class="field">
            <label for="capa">URL da imagem</label>
            <input id="capa" v-model="n.imagemCapa" class="input" placeholder="https://… ou escolha na Mídia" />
          </div>
          <div class="field">
            <label for="legenda">Legenda</label>
            <input id="legenda" v-model="n.legendaCapa" class="input" />
          </div>
          <div class="field">
            <label for="credito">Crédito</label>
            <input id="credito" v-model="n.creditoCapa" class="input" placeholder="Foto: Nome / Agência" />
          </div>
        </section>

        <section class="card bloco">
          <h3>Tags</h3>
          <div class="tags">
            <span v-for="t in n.tags" :key="t" class="chip">
              {{ t }}
              <button :aria-label="`Remover ${t}`" @click="n.tags = n.tags.filter((x) => x !== t)"><X :size="12" /></button>
            </span>
          </div>
          <input v-model="novaTag" class="input" placeholder="Digite e tecle Enter" @keydown.enter.prevent="addTag" />
        </section>

        <section class="card bloco">
          <h3>SEO e compartilhamento</h3>
          <div class="google">
            <span class="url">jornalportodopecem.com.br › noticia › {{ n.slug || 'slug' }}</span>
            <span class="gt">{{ seoTitulo.slice(0, 60) }}{{ seoTitulo.length > 60 ? '…' : '' }}</span>
            <span class="gd">{{ seoDesc.slice(0, 155) }}{{ seoDesc.length > 155 ? '…' : '' }}</span>
          </div>
          <div class="field">
            <label for="slug">Slug</label>
            <input id="slug" v-model="n.slug" class="input mono" @input="slugManual = true" />
          </div>
          <div class="field">
            <label for="seot">Título SEO <span class="muted">({{ n.seoTitulo.length }}/60)</span></label>
            <input id="seot" v-model="n.seoTitulo" class="input" :placeholder="n.titulo" />
          </div>
          <div class="field">
            <label for="seod">Descrição <span class="muted">({{ n.seoDescricao.length }}/155)</span></label>
            <textarea id="seod" v-model="n.seoDescricao" class="textarea" rows="3" :placeholder="n.linhaFina" />
          </div>
        </section>
      </aside>
    </div>

    <!-- Prévia no estilo do site -->
    <AppModal v-if="previa" titulo="Prévia da matéria" largura="760px" @fechar="previa = false">
      <article class="artigo">
        <span class="art-editoria">{{ ui.nomeEditoria(n.editoriaId) }}</span>
        <h1>{{ n.titulo || 'Título da notícia' }}</h1>
        <p v-if="n.linhaFina" class="art-fina">{{ n.linhaFina }}</p>
        <figure>
          <CapaPlaceholder :url="n.imagemCapa" :cor="ui.corEditoria(n.editoriaId)" />
          <figcaption v-if="n.legendaCapa || n.creditoCapa">{{ n.legendaCapa }} <em>{{ n.creditoCapa }}</em></figcaption>
        </figure>
        <!-- eslint-disable-next-line vue/no-v-html — HTML gerado e escapado em corpoHtml -->
        <div class="art-corpo" v-html="corpoHtml" />
      </article>
    </AppModal>
  </div>
</template>

<style scoped>
.acoes-barra {
  position: sticky;
  top: var(--topbar-h);
  z-index: 10;
  display: flex;
  align-items: center;
  gap: var(--sp-2);
  padding: var(--sp-3) var(--sp-6);
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  flex-wrap: wrap;
}

.estado {
  display: flex;
  align-items: center;
  gap: var(--sp-3);
  flex: 1;
  font-size: var(--fs-xs);
  min-width: 180px;
}

.layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 340px;
  gap: var(--sp-6);
  padding: var(--sp-6);
  max-width: 1320px;
  margin: 0 auto;
}

.texto {
  display: flex;
  flex-direction: column;
  gap: var(--sp-4);
}

.titulo,
.fina {
  width: 100%;
  border: 0;
  background: transparent;
  resize: none;
  padding: 0;
}

.titulo {
  font-family: var(--font-headline);
  font-size: 2.1rem;
  font-weight: 700;
  line-height: 1.2;
  letter-spacing: -0.01em;
}

.fina {
  font-size: var(--fs-lg);
  color: var(--text-soft);
  line-height: 1.45;
}

.titulo:focus,
.fina:focus {
  box-shadow: none;
}

.titulo::placeholder,
.fina::placeholder {
  color: var(--ink-300);
}

.contador {
  font-size: var(--fs-xs);
  color: var(--text-muted);
}

.contador.alerta {
  color: var(--warning-600);
}

.corpo-box {
  border: 1px solid var(--border-strong);
  border-radius: var(--radius);
  background: var(--surface);
  overflow: hidden;
}

.corpo-box:focus-within {
  border-color: var(--accent);
  box-shadow: var(--focus);
}

.toolbar {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 6px 8px;
  border-bottom: 1px solid var(--border);
  background: var(--surface-sunken);
}

.toolbar button {
  width: 32px;
  height: 32px;
  display: grid;
  place-items: center;
  border: 0;
  border-radius: var(--radius-sm);
  background: none;
  color: var(--text-soft);
  cursor: pointer;
}

.toolbar button:hover {
  background: var(--accent-soft);
  color: var(--accent);
}

.metricas {
  margin-left: auto;
  font-size: var(--fs-xs);
  padding-right: 6px;
}

.corpo {
  display: block;
  width: 100%;
  min-height: 460px;
  padding: var(--sp-5);
  border: 0;
  background: transparent;
  resize: vertical;
  font-size: 1.05rem;
  line-height: 1.75;
}

.corpo:focus {
  box-shadow: none;
}

.lateral {
  display: flex;
  flex-direction: column;
  gap: var(--sp-4);
}

.bloco {
  display: flex;
  flex-direction: column;
  gap: var(--sp-3);
  padding: var(--sp-4);
}

.bloco h3 {
  font-size: var(--fs-sm);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-muted);
}

.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.tags .chip {
  background: var(--accent-soft);
  color: var(--accent);
}

.tags button {
  display: grid;
  border: 0;
  background: none;
  color: inherit;
  cursor: pointer;
  padding: 0;
}

.google {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--sp-3);
  border-radius: var(--radius-sm);
  background: var(--surface-sunken);
  font-family: Arial, sans-serif;
}

.google .url {
  font-size: 12px;
  color: var(--text-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.google .gt {
  font-size: 17px;
  color: #1a0dab;
  line-height: 1.3;
}

:root[data-theme='dark'] .google .gt {
  color: #8ab4f8;
}

.google .gd {
  font-size: 13px;
  color: var(--text-soft);
  line-height: 1.45;
}

.mono {
  font-family: var(--font-mono);
  font-size: var(--fs-xs);
}

.invalido {
  border-color: var(--danger-600) !important;
}

.titulo.invalido {
  border-bottom: 2px solid var(--danger-600) !important;
}

.msg-erro {
  font-size: var(--fs-xs);
  color: var(--danger-600);
}

/* Prévia — imita a página de notícia do site */
.artigo h1 {
  font-family: var(--font-headline);
  font-size: 1.9rem;
  margin: 6px 0 10px;
}

.art-editoria {
  font-size: var(--fs-xs);
  font-weight: 700;
  text-transform: uppercase;
  color: var(--teal-500);
}

.art-fina {
  font-size: var(--fs-lg);
  color: var(--text-soft);
  margin: 0 0 16px;
}

figure {
  margin: 0 0 20px;
}

figcaption {
  font-size: var(--fs-xs);
  color: var(--text-muted);
  margin-top: 6px;
}

.art-corpo {
  font-size: 1.05rem;
  line-height: 1.8;
}

.art-corpo :deep(h2) {
  font-size: 1.25rem;
  margin: 1.4em 0 0.4em;
}

.art-corpo :deep(blockquote) {
  margin: 1em 0;
  padding: 4px 0 4px 16px;
  border-left: 3px solid var(--teal-500);
  font-family: var(--font-headline);
  font-size: 1.15rem;
}

@media (max-width: 1080px) {
  .layout {
    grid-template-columns: minmax(0, 1fr);
  }
}

@media (max-width: 720px) {
  .acoes-barra,
  .layout {
    padding-left: var(--sp-4);
    padding-right: var(--sp-4);
  }
  .titulo {
    font-size: 1.6rem;
  }
}
</style>
