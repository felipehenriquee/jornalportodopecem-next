<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { FileText, Clock, CalendarClock, PenLine, Megaphone, Eye, ArrowRight } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import { noticiasApi, type ResumoPainel } from '@/services/api'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import type { Noticia } from '@/types'
import { fmtNum, tempoRelativo } from '@/utils/format'

const auth = useAuthStore()
const ui = useUiStore()
const resumo = ref<ResumoPainel | null>(null)
const fila = ref<Noticia[]>([])

onMounted(async () => {
  const [r, f] = await Promise.all([noticiasApi.resumo(), noticiasApi.listar({ porPagina: 6 })])
  resumo.value = r
  fila.value = f.itens.filter((n) => n.status !== 'publicada' && n.status !== 'arquivada')
})

const saudacao = computed(() => {
  const h = new Date().getHours()
  return h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'
})

const kpis = computed(() => {
  const r = resumo.value
  return [
    { rotulo: 'Publicadas', valor: r?.publicadas, icone: FileText, to: '/noticias?status=publicada' },
    { rotulo: 'Em revisão', valor: r?.revisao, icone: Clock, to: '/noticias?status=revisao', alerta: (r?.revisao ?? 0) > 0 },
    { rotulo: 'Agendadas', valor: r?.agendadas, icone: CalendarClock, to: '/noticias?status=agendada' },
    { rotulo: 'Rascunhos', valor: r?.rascunhos, icone: PenLine, to: '/noticias?status=rascunho' },
    { rotulo: 'Anúncios ativos', valor: r?.anunciosAtivos, icone: Megaphone, to: '/anuncios' },
  ]
})

/* ---- Gráfico de visualizações (SVG simples, sem dependências) ---- */
const W = 640
const H = 180
const P = 8
const serie = computed(() => resumo.value?.visualizacoes14d ?? [])
const total14 = computed(() => serie.value.reduce((a, b) => a + b, 0))
const maxV = computed(() => Math.max(...serie.value, 1) * 1.1)
const pontos = computed(() =>
  serie.value.map((v, i) => [P + (i * (W - 2 * P)) / Math.max(serie.value.length - 1, 1), H - P - (v / maxV.value) * (H - 2 * P)] as const),
)
const linha = computed(() => pontos.value.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' '))
const area = computed(() => (pontos.value.length ? `${linha.value} L${W - P},${H - P} L${P},${H - P} Z` : ''))
const rotulosDias = computed(() =>
  serie.value.map((_, i) => {
    const d = new Date()
    d.setDate(d.getDate() - (serie.value.length - 1 - i))
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })
  }),
)
const hover = ref<number | null>(null)
</script>

<template>
  <div class="page">
    <PageHeader
      eyebrow="Painel"
      :titulo="`${saudacao}, ${auth.usuario?.nome.split(' ')[0]}`"
      subtitulo="Resumo da redação e do que precisa da sua atenção hoje."
    >
      <RouterLink to="/noticias/nova" class="btn btn-primary">Escrever notícia</RouterLink>
    </PageHeader>

    <section class="kpis">
      <RouterLink v-for="k in kpis" :key="k.rotulo" :to="k.to" class="card kpi" :class="{ alerta: k.alerta }">
        <span class="ic"><component :is="k.icone" :size="18" /></span>
        <span class="valor">{{ k.valor ?? '–' }}</span>
        <span class="rot">{{ k.rotulo }}</span>
      </RouterLink>
    </section>

    <div class="duas">
      <section class="card">
        <div class="card-header">
          <div>
            <h2>Visualizações · últimos 14 dias</h2>
            <p class="muted mini">{{ fmtNum(total14) }} no período</p>
          </div>
          <Eye :size="18" class="muted" />
        </div>
        <div class="card-body grafico" @mouseleave="hover = null">
          <svg :viewBox="`0 0 ${W} ${H}`" preserveAspectRatio="none" role="img" aria-label="Gráfico de visualizações diárias">
            <defs>
              <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stop-color="var(--accent)" stop-opacity=".28" />
                <stop offset="1" stop-color="var(--accent)" stop-opacity="0" />
              </linearGradient>
            </defs>
            <line v-for="i in 3" :key="i" :x1="P" :x2="W - P" :y1="(H / 4) * i" :y2="(H / 4) * i" stroke="var(--border)" stroke-dasharray="3 4" />
            <path :d="area" fill="url(#g)" />
            <path :d="linha" fill="none" stroke="var(--accent)" stroke-width="2.5" stroke-linejoin="round" vector-effect="non-scaling-stroke" />
            <g v-for="([x, y], i) in pontos" :key="i">
              <rect :x="x - (W / serie.length) / 2" y="0" :width="W / serie.length" :height="H" fill="transparent" @mouseenter="hover = i" />
              <circle v-if="hover === i" :cx="x" :cy="y" r="5" fill="var(--surface)" stroke="var(--accent)" stroke-width="2.5" vector-effect="non-scaling-stroke" />
            </g>
          </svg>
          <div v-if="hover !== null" class="tip" :style="{ left: `${(pontos[hover]![0] / W) * 100}%` }">
            <strong>{{ fmtNum(serie[hover]!) }}</strong> · {{ rotulosDias[hover] }}
          </div>
          <div class="eixo muted">
            <span>{{ rotulosDias[0] }}</span><span>{{ rotulosDias[rotulosDias.length - 1] }}</span>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-header"><h2>Mais lidas</h2></div>
        <ol class="ranking">
          <li v-for="(n, i) in resumo?.maisLidas ?? []" :key="n.id">
            <span class="pos">{{ i + 1 }}</span>
            <div>
              <RouterLink :to="`/noticias/${n.id}`" class="tit">{{ n.titulo }}</RouterLink>
              <p class="muted mini">
                <span class="dot" :style="{ background: ui.corEditoria(n.editoriaId) }" />
                {{ ui.nomeEditoria(n.editoriaId) }} · {{ fmtNum(n.visualizacoes) }} leituras
              </p>
            </div>
          </li>
        </ol>
      </section>
    </div>

    <section class="card">
      <div class="card-header">
        <h2>Fila da redação</h2>
        <RouterLink to="/noticias" class="ver">Ver todas <ArrowRight :size="14" /></RouterLink>
      </div>
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr><th>Título</th><th>Editoria</th><th>Status</th><th>Atualizada</th></tr>
          </thead>
          <tbody>
            <tr v-for="n in fila" :key="n.id">
              <td><RouterLink :to="`/noticias/${n.id}`" class="tit">{{ n.titulo }}</RouterLink></td>
              <td class="muted">{{ ui.nomeEditoria(n.editoriaId) }}</td>
              <td><StatusBadge :status="n.status" /></td>
              <td class="muted">{{ tempoRelativo(n.atualizadaEm) }}</td>
            </tr>
            <tr v-if="!fila.length"><td colspan="4" class="muted">Nada pendente. 🎉</td></tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>

<style scoped>
.kpis {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: var(--sp-4);
  margin-bottom: var(--sp-5);
}

.kpi {
  display: grid;
  grid-template-columns: auto 1fr;
  grid-template-rows: auto auto;
  column-gap: var(--sp-3);
  padding: var(--sp-4) var(--sp-5);
  color: var(--text);
  transition: border-color 0.15s, transform 0.15s;
}

.kpi:hover {
  border-color: var(--accent);
  transform: translateY(-1px);
}

.ic {
  grid-row: span 2;
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  border-radius: var(--radius);
  background: var(--accent-soft);
  color: var(--accent);
  align-self: center;
}

.kpi.alerta .ic {
  background: var(--warning-100);
  color: var(--warning-600);
}

.valor {
  font-size: var(--fs-xl);
  font-weight: 700;
  line-height: 1.1;
  font-variant-numeric: tabular-nums;
}

.rot {
  font-size: var(--fs-xs);
  color: var(--text-muted);
}

.duas {
  display: grid;
  grid-template-columns: 1.6fr 1fr;
  gap: var(--sp-5);
  margin-bottom: var(--sp-5);
}

.mini {
  margin: 2px 0 0;
  font-size: var(--fs-xs);
}

.grafico {
  position: relative;
}

.grafico svg {
  width: 100%;
  height: 200px;
  display: block;
}

.tip {
  position: absolute;
  top: 8px;
  transform: translateX(-50%);
  padding: 4px 10px;
  border-radius: var(--radius-sm);
  background: var(--navy-900);
  color: #fff;
  font-size: var(--fs-xs);
  white-space: nowrap;
  pointer-events: none;
}

.eixo {
  display: flex;
  justify-content: space-between;
  font-size: var(--fs-xs);
  margin-top: 6px;
}

.ranking {
  list-style: none;
  margin: 0;
  padding: var(--sp-2) var(--sp-5) var(--sp-4);
}

.ranking li {
  display: flex;
  gap: var(--sp-3);
  padding: var(--sp-3) 0;
  border-bottom: 1px solid var(--border);
}

.ranking li:last-child {
  border-bottom: 0;
}

.pos {
  font-family: var(--font-headline);
  font-size: var(--fs-xl);
  font-weight: 700;
  line-height: 1;
  color: var(--accent);
  min-width: 22px;
}

.tit {
  color: var(--text);
  font-weight: 500;
}

.tit:hover {
  color: var(--accent);
}

.dot {
  display: inline-block;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  margin-right: 2px;
}

.ver {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: var(--fs-sm);
  font-weight: 500;
}

@media (max-width: 1200px) {
  .kpis {
    grid-template-columns: repeat(3, 1fr);
  }
}

@media (max-width: 900px) {
  .duas {
    grid-template-columns: 1fr;
  }
  .kpis {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
