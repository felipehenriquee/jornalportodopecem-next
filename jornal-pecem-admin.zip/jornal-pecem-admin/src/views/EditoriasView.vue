<script setup lang="ts">
import { computed, ref } from 'vue'
import { Plus, Pencil, Trash2, CornerDownRight } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import AppModal from '@/components/ui/AppModal.vue'
import AppToggle from '@/components/ui/AppToggle.vue'
import { editoriasApi } from '@/services/api'
import { useUiStore } from '@/stores/ui'
import type { Editoria } from '@/types'
import { slugify } from '@/utils/format'

const ui = useUiStore()
ui.carregarEditorias()

const paleta = ['#009999', '#142248', '#2a3f74', '#1fb3b3', '#007373', '#c9a14a', '#b7791f', '#495057']

/** Lista em árvore: mães seguidas de filhas, na ordem do menu */
const arvore = computed(() => {
  const raizes = ui.editorias.filter((e) => !e.paiId).sort((a, b) => a.ordemMenu - b.ordemMenu)
  return raizes.flatMap((r) => [r, ...ui.editorias.filter((e) => e.paiId === r.id).sort((a, b) => a.ordemMenu - b.ordemMenu)])
})

const edicao = ref<Editoria | null>(null)
const remover = ref<Editoria | null>(null)

function nova() {
  edicao.value = { id: 0, nome: '', slug: '', descricao: '', cor: paleta[0]!, paiId: null, ordemMenu: ui.editorias.length + 1, ativa: true }
}

async function salvar() {
  const e = edicao.value!
  if (!e.nome.trim()) return
  e.slug ||= slugify(e.nome)
  await editoriasApi.salvar(e.id ? e : { ...e, id: undefined })
  await ui.carregarEditorias(true)
  ui.notificar(e.id ? 'Editoria atualizada' : 'Editoria criada')
  edicao.value = null
}

async function alternar(e: Editoria) {
  await editoriasApi.salvar({ ...e, ativa: !e.ativa })
  await ui.carregarEditorias(true)
}

async function confirmarRemocao() {
  await editoriasApi.remover(remover.value!.id)
  await ui.carregarEditorias(true)
  ui.notificar('Editoria removida')
  remover.value = null
}
</script>

<template>
  <div class="page">
    <PageHeader eyebrow="Estrutura" titulo="Editorias" subtitulo="As seções do site e a ordem em que aparecem no menu.">
      <button class="btn btn-primary" @click="nova"><Plus /> Nova editoria</button>
    </PageHeader>

    <section class="card">
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr><th>Editoria</th><th>Endereço</th><th>Descrição</th><th>No menu</th><th><span class="sr-only">Ações</span></th></tr>
          </thead>
          <tbody>
            <tr v-for="e in arvore" :key="e.id" :class="{ inativa: !e.ativa }">
              <td>
                <div class="nome" :class="{ filha: e.paiId }">
                  <CornerDownRight v-if="e.paiId" :size="14" class="muted" />
                  <span class="cor" :style="{ background: e.cor }" />
                  <strong>{{ e.nome }}</strong>
                </div>
              </td>
              <td class="mono muted">/noticias/{{ e.slug }}</td>
              <td class="muted">{{ e.descricao }}</td>
              <td><AppToggle :model-value="e.ativa" @update:model-value="alternar(e)" /></td>
              <td>
                <div class="acoes">
                  <button class="btn btn-ghost btn-icon" aria-label="Editar" @click="edicao = { ...e }"><Pencil /></button>
                  <button class="btn btn-danger btn-icon" aria-label="Remover" @click="remover = e"><Trash2 /></button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <AppModal v-if="edicao" :titulo="edicao.id ? 'Editar editoria' : 'Nova editoria'" @fechar="edicao = null">
      <div class="field">
        <label for="en">Nome</label>
        <input id="en" v-model="edicao.nome" class="input" @input="!edicao.id && (edicao.slug = slugify(edicao.nome))" />
      </div>
      <div class="field">
        <label for="es">Slug</label>
        <input id="es" v-model="edicao.slug" class="input mono" />
        <span class="hint">jornalportodopecem.com.br/noticias/{{ edicao.slug || '…' }}</span>
      </div>
      <div class="field">
        <label for="ed">Descrição</label>
        <input id="ed" v-model="edicao.descricao" class="input" />
      </div>
      <div class="field">
        <label for="ep">Dentro de</label>
        <select id="ep" v-model="edicao.paiId" class="select">
          <option :value="null">— Nível principal —</option>
          <option v-for="p in ui.editorias.filter((x) => !x.paiId && x.id !== edicao!.id)" :key="p.id" :value="p.id">{{ p.nome }}</option>
        </select>
      </div>
      <div class="field">
        <label>Cor do rótulo</label>
        <div class="paleta">
          <button
            v-for="c in paleta"
            :key="c"
            type="button"
            class="amostra"
            :class="{ sel: edicao.cor === c }"
            :style="{ background: c }"
            :aria-label="`Cor ${c}`"
            @click="edicao.cor = c"
          />
        </div>
      </div>
      <template #rodape>
        <button class="btn btn-ghost" @click="edicao = null">Cancelar</button>
        <button class="btn btn-primary" :disabled="!edicao.nome.trim()" @click="salvar">Salvar</button>
      </template>
    </AppModal>

    <AppModal v-if="remover" titulo="Remover editoria?" @fechar="remover = null">
      <p style="margin: 0">
        As notícias de <strong>{{ remover.nome }}</strong> ficarão sem editoria. Se quiser só tirar do menu, desative em vez de remover.
      </p>
      <template #rodape>
        <button class="btn btn-ghost" @click="remover = null">Cancelar</button>
        <button class="btn btn-primary" style="background: var(--danger-600)" @click="confirmarRemocao">Remover</button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.nome {
  display: flex;
  align-items: center;
  gap: 10px;
}
.nome.filha {
  padding-left: 18px;
}
.cor {
  width: 10px;
  height: 10px;
  border-radius: 3px;
  flex: none;
}
.inativa td {
  opacity: 0.55;
}
.inativa td:nth-child(4) {
  opacity: 1;
}
.mono {
  font-family: var(--font-mono);
  font-size: var(--fs-xs);
}
.acoes {
  display: flex;
  gap: 6px;
  justify-content: flex-end;
}
.paleta {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
.amostra {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  border: 2px solid var(--surface);
  box-shadow: 0 0 0 1px var(--border-strong);
  cursor: pointer;
}
.amostra.sel {
  box-shadow: 0 0 0 2px var(--accent);
}
</style>
