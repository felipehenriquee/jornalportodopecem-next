<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { Plus, Pencil, MousePointerClick, Eye } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import AppModal from '@/components/ui/AppModal.vue'
import AppToggle from '@/components/ui/AppToggle.vue'
import { anunciosApi } from '@/services/api'
import { useUiStore } from '@/stores/ui'
import type { Anuncio, PosicaoAnuncio } from '@/types'
import { fmtData, fmtNum, posicaoLabel } from '@/utils/format'

const ui = useUiStore()
const itens = ref<Anuncio[]>([])
const edicao = ref<Anuncio | null>(null)

onMounted(async () => (itens.value = await anunciosApi.listar()))

const hoje = new Date().toISOString().slice(0, 10)
function situacao(a: Anuncio) {
  if (!a.ativo) return { rotulo: 'Pausado', classe: 'pausado' }
  if (a.fim < hoje) return { rotulo: 'Encerrado', classe: 'pausado' }
  if (a.inicio > hoje) return { rotulo: 'Programado', classe: 'programado' }
  return { rotulo: 'No ar', classe: 'noar' }
}

const ctr = (a: Anuncio) => (a.impressoes ? ((a.cliques / a.impressoes) * 100).toFixed(2).replace('.', ',') + '%' : '—')

const totais = computed(() => ({
  noAr: itens.value.filter((a) => situacao(a).classe === 'noar').length,
  impressoes: itens.value.reduce((s, a) => s + a.impressoes, 0),
  cliques: itens.value.reduce((s, a) => s + a.cliques, 0),
}))

const posicoes = Object.keys(posicaoLabel) as PosicaoAnuncio[]

function novo() {
  edicao.value = { id: 0, cliente: '', titulo: '', posicao: 'lateral', imagem: '', link: '', inicio: hoje, fim: hoje, ativo: true, impressoes: 0, cliques: 0 }
}

async function salvar() {
  const a = edicao.value!
  if (!a.cliente.trim() || a.fim < a.inicio) {
    ui.notificar('Preencha o cliente e confira as datas', 'erro')
    return
  }
  const salvo = await anunciosApi.salvar(a.id ? a : { ...a, id: undefined })
  itens.value = a.id ? itens.value.map((x) => (x.id === a.id ? salvo : x)) : [salvo, ...itens.value]
  ui.notificar('Anúncio salvo')
  edicao.value = null
}

async function alternar(a: Anuncio) {
  a.ativo = !a.ativo
  await anunciosApi.salvar(a)
}
</script>

<template>
  <div class="page">
    <PageHeader eyebrow="Comercial" titulo="Anúncios" subtitulo="Os espaços “Anuncie aqui” do site e seus contratos.">
      <button class="btn btn-primary" @click="novo"><Plus /> Novo anúncio</button>
    </PageHeader>

    <section class="resumo">
      <div class="card r"><span class="muted">No ar agora</span><strong>{{ totais.noAr }}</strong></div>
      <div class="card r"><span class="muted"><Eye :size="14" /> Impressões</span><strong>{{ fmtNum(totais.impressoes) }}</strong></div>
      <div class="card r"><span class="muted"><MousePointerClick :size="14" /> Cliques</span><strong>{{ fmtNum(totais.cliques) }}</strong></div>
    </section>

    <section class="cards">
      <article v-for="a in itens" :key="a.id" class="card anuncio">
        <div class="espaco" :class="a.posicao">
          <span>{{ posicaoLabel[a.posicao] }}</span>
        </div>
        <div class="info">
          <div class="linha">
            <span class="sit" :class="situacao(a).classe">{{ situacao(a).rotulo }}</span>
            <AppToggle :model-value="a.ativo" :aria-label="a.ativo ? 'Pausar' : 'Ativar'" @update:model-value="alternar(a)" />
          </div>
          <h3>{{ a.cliente }}</h3>
          <p class="muted">{{ a.titulo }}</p>
          <p class="periodo">{{ fmtData(a.inicio) }} → {{ fmtData(a.fim) }}</p>
          <dl>
            <div><dt>Impressões</dt><dd>{{ fmtNum(a.impressoes) }}</dd></div>
            <div><dt>Cliques</dt><dd>{{ fmtNum(a.cliques) }}</dd></div>
            <div><dt>CTR</dt><dd>{{ ctr(a) }}</dd></div>
          </dl>
          <button class="btn btn-ghost" @click="edicao = { ...a }"><Pencil /> Editar</button>
        </div>
      </article>
    </section>

    <AppModal v-if="edicao" :titulo="edicao.id ? 'Editar anúncio' : 'Novo anúncio'" @fechar="edicao = null">
      <div class="field"><label for="ac">Cliente</label><input id="ac" v-model="edicao.cliente" class="input" /></div>
      <div class="field"><label for="at">Campanha</label><input id="at" v-model="edicao.titulo" class="input" /></div>
      <div class="field">
        <label for="ap">Posição</label>
        <select id="ap" v-model="edicao.posicao" class="select">
          <option v-for="p in posicoes" :key="p" :value="p">{{ posicaoLabel[p] }}</option>
        </select>
      </div>
      <div class="field"><label for="ai">Imagem (URL)</label><input id="ai" v-model="edicao.imagem" class="input" /></div>
      <div class="field"><label for="al">Link de destino</label><input id="al" v-model="edicao.link" type="url" class="input" placeholder="https://" /></div>
      <div class="duas">
        <div class="field"><label for="ain">Início</label><input id="ain" v-model="edicao.inicio" type="date" class="input" /></div>
        <div class="field"><label for="afi">Fim</label><input id="afi" v-model="edicao.fim" type="date" class="input" /></div>
      </div>
      <template #rodape>
        <button class="btn btn-ghost" @click="edicao = null">Cancelar</button>
        <button class="btn btn-primary" @click="salvar">Salvar</button>
      </template>
    </AppModal>
  </div>
</template>

<style scoped>
.resumo {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--sp-4);
  margin-bottom: var(--sp-5);
}
.r {
  padding: var(--sp-4) var(--sp-5);
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.r span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: var(--fs-xs);
}
.r strong {
  font-size: var(--fs-xl);
  font-variant-numeric: tabular-nums;
}
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: var(--sp-4);
}
.anuncio {
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
/* Espaço do anúncio desenhado como no site: bloco tracejado sobre fundo névoa */
.espaco {
  margin: var(--sp-4) var(--sp-4) 0;
  height: 110px;
  display: grid;
  place-items: center;
  border: 2px dashed var(--border-strong);
  border-radius: var(--radius);
  background: var(--surface-sunken);
  color: var(--text-muted);
  font-size: var(--fs-xs);
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}
.espaco.lateral {
  height: 140px;
}
.info {
  padding: var(--sp-4);
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.linha {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 6px;
}
.sit {
  font-size: var(--fs-xs);
  font-weight: 700;
  padding: 2px 10px;
  border-radius: 999px;
}
.noar { background: var(--success-100); color: var(--success-600); }
.programado { background: var(--info-100); color: var(--navy-700); }
.pausado { background: var(--ink-100); color: var(--ink-500); }
:root[data-theme='dark'] .programado { color: #9db2e6; }
h3 {
  font-size: var(--fs-md);
}
.info p {
  margin: 0;
  font-size: var(--fs-sm);
}
.periodo {
  color: var(--text-soft);
  margin-top: 4px !important;
}
dl {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
  margin: 12px 0;
  padding: 10px 0;
  border-top: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
}
dt {
  font-size: 0.6875rem;
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
dd {
  margin: 0;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.duas {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
@media (max-width: 640px) {
  .resumo {
    grid-template-columns: 1fr;
  }
}
</style>
