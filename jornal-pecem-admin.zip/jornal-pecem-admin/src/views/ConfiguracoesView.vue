<script setup lang="ts">
import { reactive } from 'vue'
import { Save } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import AppToggle from '@/components/ui/AppToggle.vue'
import { useUiStore } from '@/stores/ui'
import { API_URL, usandoMock } from '@/services/http'

const ui = useUiStore()

/** Configurações gerais do site — ligue a GET/PUT /configuracoes quando a API existir */
const cfg = reactive({
  nomeSite: 'Jornal Porto do Pecém',
  localDataline: 'Pecém',
  emailContato: 'contato@jornalportodopecem.com.br',
  mostrarCotacaoDolar: true,
  noticiasNaHome: 4,
  exigirRevisao: true,
  instagram: '',
  linkedin: '',
})

function salvar() {
  ui.notificar('Configurações salvas')
}
</script>

<template>
  <div class="page estreita">
    <PageHeader eyebrow="Sistema" titulo="Configurações">
      <button class="btn btn-primary" @click="salvar"><Save /> Salvar</button>
    </PageHeader>

    <section class="card secao">
      <div class="desc"><h2>Identidade</h2><p class="muted">Como o jornal aparece no topo do site.</p></div>
      <div class="campos">
        <div class="field"><label for="cn">Nome do site</label><input id="cn" v-model="cfg.nomeSite" class="input" /></div>
        <div class="field">
          <label for="cl">Local na data do cabeçalho</label>
          <input id="cl" v-model="cfg.localDataline" class="input" />
          <span class="hint">Aparece como “{{ cfg.localDataline }}, 05 de novembro de 2026”.</span>
        </div>
        <div class="field"><label for="ce">E-mail de contato</label><input id="ce" v-model="cfg.emailContato" type="email" class="input" /></div>
      </div>
    </section>

    <section class="card secao">
      <div class="desc"><h2>Página inicial</h2><p class="muted">Blocos e quantidades da home.</p></div>
      <div class="campos">
        <div class="field">
          <label for="ch">Notícias em “Últimas notícias”</label>
          <input id="ch" v-model.number="cfg.noticiasNaHome" type="number" min="1" max="12" class="input curta" />
        </div>
        <AppToggle v-model="cfg.mostrarCotacaoDolar" rotulo="Mostrar cotação do dólar (TradingView)" />
      </div>
    </section>

    <section class="card secao">
      <div class="desc"><h2>Fluxo editorial</h2><p class="muted">Regras para publicação.</p></div>
      <div class="campos">
        <AppToggle v-model="cfg.exigirRevisao" rotulo="Repórteres e colunistas precisam de revisão antes de publicar" />
      </div>
    </section>

    <section class="card secao">
      <div class="desc"><h2>Redes sociais</h2></div>
      <div class="campos">
        <div class="field"><label for="ci">Instagram</label><input id="ci" v-model="cfg.instagram" class="input" placeholder="https://instagram.com/…" /></div>
        <div class="field"><label for="cli">LinkedIn</label><input id="cli" v-model="cfg.linkedin" class="input" placeholder="https://linkedin.com/company/…" /></div>
      </div>
    </section>

    <section class="card secao">
      <div class="desc"><h2>Aparência do painel</h2></div>
      <div class="campos">
        <AppToggle :model-value="ui.tema === 'escuro'" rotulo="Tema escuro" @update:model-value="(v: boolean) => (ui.tema = v ? 'escuro' : 'claro')" />
      </div>
    </section>

    <section class="card secao">
      <div class="desc"><h2>Integração</h2><p class="muted">Definida em <code>.env</code>.</p></div>
      <div class="campos">
        <p class="api">
          <span class="chip">{{ usandoMock ? 'Dados de demonstração' : 'API conectada' }}</span>
          <code>{{ API_URL || 'VITE_API_URL não definido' }}</code>
        </p>
      </div>
    </section>
  </div>
</template>

<style scoped>
.estreita {
  max-width: 960px;
}
.secao {
  display: grid;
  grid-template-columns: 240px 1fr;
  gap: var(--sp-5);
  padding: var(--sp-5);
  margin-bottom: var(--sp-4);
}
.desc h2 {
  font-size: var(--fs-md);
}
.desc p {
  margin: 4px 0 0;
  font-size: var(--fs-sm);
}
.campos {
  display: grid;
  gap: var(--sp-4);
}
.curta {
  max-width: 120px;
}
code {
  font-family: var(--font-mono);
  font-size: var(--fs-xs);
}
.api {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0;
  flex-wrap: wrap;
}
@media (max-width: 760px) {
  .secao {
    grid-template-columns: 1fr;
  }
}
</style>
