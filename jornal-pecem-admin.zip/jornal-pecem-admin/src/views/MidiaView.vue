<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { Upload, Search, Copy, Trash2 } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import CapaPlaceholder from '@/components/ui/CapaPlaceholder.vue'
import { midiasApi } from '@/services/api'
import { useUiStore } from '@/stores/ui'
import type { Midia } from '@/types'
import { fmtData } from '@/utils/format'

const ui = useUiStore()
const itens = ref<Midia[]>([])
const busca = ref('')
const selecionada = ref<Midia | null>(null)
const arrastando = ref(false)
const cores = ['#009999', '#142248', '#1fb3b3', '#2a3f74', '#007373', '#c9a14a']

onMounted(async () => (itens.value = await midiasApi.listar()))

const filtrados = computed(() => itens.value.filter((m) => m.nome.includes(busca.value.toLowerCase())))

/**
 * Upload: no modo mock só cria a entrada local com um object URL.
 * Com API, troque por um POST multipart em /midias.
 */
async function enviar(arquivos: FileList | null) {
  if (!arquivos) return
  for (const f of Array.from(arquivos)) {
    const m = await midiasApi.salvar({
      nome: f.name,
      url: URL.createObjectURL(f),
      tipo: f.type === 'application/pdf' ? 'pdf' : 'imagem',
      tamanhoKb: Math.round(f.size / 1024),
      credito: '',
      enviadaEm: new Date().toISOString(),
    })
    itens.value.unshift(m)
  }
  ui.notificar(`${arquivos.length} arquivo(s) enviado(s)`)
}

function soltar(e: DragEvent) {
  arrastando.value = false
  enviar(e.dataTransfer?.files ?? null)
}

async function copiar(m: Midia) {
  try {
    await navigator.clipboard.writeText(m.url || m.nome)
    ui.notificar('Endereço copiado', 'info')
  } catch {
    ui.notificar('Não foi possível copiar', 'erro')
  }
}

async function remover(m: Midia) {
  await midiasApi.remover(m.id)
  itens.value = itens.value.filter((x) => x.id !== m.id)
  selecionada.value = null
  ui.notificar('Arquivo removido')
}
</script>

<template>
  <div class="page">
    <PageHeader eyebrow="Acervo" titulo="Biblioteca de mídia" subtitulo="Fotos e arquivos usados nas matérias.">
      <label class="btn btn-primary">
        <Upload /> Enviar arquivos
        <input type="file" accept="image/*,application/pdf" multiple class="sr-only" @change="enviar(($event.target as HTMLInputElement).files)" />
      </label>
    </PageHeader>

    <div
      class="soltar"
      :class="{ ativo: arrastando }"
      @dragover.prevent="arrastando = true"
      @dragleave="arrastando = false"
      @drop.prevent="soltar"
    >
      <Upload :size="20" />
      <span>Arraste imagens para cá ou use <strong>Enviar arquivos</strong></span>
    </div>

    <div class="topo">
      <label class="busca">
        <Search :size="16" />
        <input v-model="busca" class="input" placeholder="Buscar arquivo…" aria-label="Buscar arquivo" />
      </label>
      <span class="muted">{{ filtrados.length }} arquivos</span>
    </div>

    <div class="conteudo">
      <ul class="grade">
        <li v-for="(m, i) in filtrados" :key="m.id">
          <button class="item" :class="{ sel: selecionada?.id === m.id }" @click="selecionada = m">
            <CapaPlaceholder :url="m.url" :cor="cores[i % cores.length]" :alt="m.nome" />
            <span class="nome">{{ m.nome }}</span>
          </button>
        </li>
      </ul>

      <aside v-if="selecionada" class="card detalhe">
        <CapaPlaceholder :url="selecionada.url" :alt="selecionada.nome" />
        <dl>
          <dt>Arquivo</dt><dd>{{ selecionada.nome }}</dd>
          <dt>Tamanho</dt><dd>{{ selecionada.tamanhoKb }} KB</dd>
          <dt>Enviado</dt><dd>{{ fmtData(selecionada.enviadaEm) }}</dd>
        </dl>
        <div class="field">
          <label for="cred">Crédito</label>
          <input id="cred" v-model="selecionada.credito" class="input" @change="midiasApi.salvar(selecionada!)" />
        </div>
        <div class="botoes">
          <button class="btn btn-ghost" @click="copiar(selecionada)"><Copy /> Copiar URL</button>
          <button class="btn btn-danger" @click="remover(selecionada)"><Trash2 /> Remover</button>
        </div>
      </aside>
    </div>
  </div>
</template>

<style scoped>
.soltar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 22px;
  margin-bottom: var(--sp-5);
  border: 2px dashed var(--border-strong);
  border-radius: var(--radius-lg);
  color: var(--text-muted);
  font-size: var(--fs-sm);
  background: var(--surface-sunken);
  transition: all 0.15s;
}
.soltar.ativo {
  border-color: var(--accent);
  background: var(--accent-soft);
  color: var(--accent);
}
.topo {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sp-3);
  margin-bottom: var(--sp-4);
  font-size: var(--fs-sm);
}
.busca {
  position: relative;
  max-width: 320px;
  flex: 1;
}
.busca svg {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--text-muted);
}
.busca .input {
  padding-left: 36px;
}
.conteudo {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: var(--sp-5);
  align-items: start;
}
.grade {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: var(--sp-4);
}
.item {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 6px;
  border: 2px solid transparent;
  border-radius: var(--radius);
  background: var(--surface);
  cursor: pointer;
  text-align: left;
}
.item:hover {
  border-color: var(--border-strong);
}
.item.sel {
  border-color: var(--accent);
}
.nome {
  font-size: var(--fs-xs);
  color: var(--text-soft);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding: 0 2px 2px;
}
.detalhe {
  width: 300px;
  padding: var(--sp-4);
  display: grid;
  gap: var(--sp-3);
  position: sticky;
  top: calc(var(--topbar-h) + 16px);
}
dl {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 4px 12px;
  margin: 0;
  font-size: var(--fs-sm);
}
dt {
  color: var(--text-muted);
}
dd {
  margin: 0;
  word-break: break-all;
}
.botoes {
  display: flex;
  gap: 8px;
}
.botoes .btn {
  flex: 1;
}
@media (max-width: 900px) {
  .conteudo {
    grid-template-columns: 1fr;
  }
  .detalhe {
    width: auto;
    position: static;
  }
}
</style>
