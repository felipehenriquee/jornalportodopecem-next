<script setup lang="ts">
/** Mostra a imagem quando houver URL; senão, um bloco com a cor da editoria */
defineProps<{ url?: string; cor?: string; alt?: string }>()
</script>

<template>
  <div class="capa" :style="{ '--c': cor ?? 'var(--teal-500)' }">
    <img v-if="url" :src="url" :alt="alt ?? ''" />
    <svg v-else viewBox="0 0 40 40" aria-hidden="true">
      <path d="M20 4l2.6 13.4L20 20l-2.6-2.6zM20 36l-2.6-13.4L20 20l2.6 2.6zM4 20l13.4-2.6L20 20l-2.6 2.6zM36 20l-13.4 2.6L20 20l2.6-2.6z" fill="#fff" fill-opacity=".55" />
    </svg>
  </div>
</template>

<style scoped>
.capa {
  position: relative;
  overflow: hidden;
  display: grid;
  place-items: center;
  background: linear-gradient(135deg, var(--c), var(--navy-900));
  aspect-ratio: 16 / 10;
  border-radius: var(--radius-sm);
}
img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
svg {
  width: 32%;
  max-width: 64px;
}
</style>
