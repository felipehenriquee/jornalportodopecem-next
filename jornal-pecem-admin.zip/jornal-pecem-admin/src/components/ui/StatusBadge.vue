<script setup lang="ts">
import type { StatusNoticia } from '@/types'
import { statusLabel } from '@/utils/format'
defineProps<{ status: StatusNoticia }>()
</script>

<template>
  <span class="badge" :class="status"><i />{{ statusLabel[status] }}</span>
</template>

<style scoped>
.badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 3px 10px;
  border-radius: 999px;
  font-size: var(--fs-xs);
  font-weight: 500;
  white-space: nowrap;
}
i {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
}
.publicada { background: var(--success-100); color: var(--success-600); }
.revisao { background: var(--warning-100); color: var(--warning-600); }
.agendada { background: var(--info-100); color: var(--navy-700); }
.rascunho { background: var(--ink-100); color: var(--ink-700); }
.arquivada { background: var(--ink-100); color: var(--ink-500); }
:root[data-theme='dark'] .agendada { color: #9db2e6; }
:root[data-theme='dark'] .rascunho, :root[data-theme='dark'] .arquivada { background: rgba(255,255,255,.06); color: var(--text-muted); }
</style>
