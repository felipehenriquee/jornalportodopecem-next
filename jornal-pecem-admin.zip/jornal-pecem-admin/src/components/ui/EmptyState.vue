<script setup lang="ts">
import { Inbox } from 'lucide-vue-next'
defineProps<{ titulo: string; texto?: string }>()
</script>

<template>
  <div class="vazio">
    <Inbox :size="28" />
    <strong>{{ titulo }}</strong>
    <p v-if="texto" class="muted">{{ texto }}</p>
    <slot />
  </div>
</template>

<style scoped>
.vazio {
  display: grid;
  justify-items: center;
  gap: 6px;
  padding: 48px 16px;
  text-align: center;
  color: var(--text-muted);
}
strong { color: var(--text); }
p { margin: 0 0 8px; font-size: var(--fs-sm); }
</style>
