<script setup lang="ts">
import { CheckCircle2, AlertCircle, Info } from 'lucide-vue-next'
import { useUiStore } from '@/stores/ui'
const ui = useUiStore()
const icones = { sucesso: CheckCircle2, erro: AlertCircle, info: Info }
</script>

<template>
  <div class="host" role="status" aria-live="polite">
    <TransitionGroup name="t">
      <div v-for="t in ui.toasts" :key="t.id" class="toast" :class="t.tipo">
        <component :is="icones[t.tipo]" :size="18" />
        <span>{{ t.texto }}</span>
      </div>
    </TransitionGroup>
  </div>
</template>

<style scoped>
.host {
  position: fixed;
  right: 20px;
  bottom: 20px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 100;
}
.toast {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 260px;
  max-width: 380px;
  padding: 12px 16px;
  border-radius: var(--radius);
  background: var(--navy-900);
  color: #fff;
  font-size: var(--fs-sm);
  box-shadow: var(--shadow-lg);
  border-left: 4px solid var(--teal-400);
}
.toast.erro { border-left-color: #ff8a7a; }
.toast.info { border-left-color: var(--sand-500); }
.t-enter-active, .t-leave-active { transition: all 0.2s ease; }
.t-enter-from, .t-leave-to { opacity: 0; transform: translateY(8px); }
</style>
