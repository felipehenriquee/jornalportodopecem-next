<script setup lang="ts">
/** Rosa-dos-ventos simplificada, inspirada no símbolo do jornal */
withDefaults(defineProps<{ tamanho?: number; comTexto?: boolean; claro?: boolean }>(), {
  tamanho: 36,
  comTexto: true,
  claro: false,
})
</script>

<template>
  <div class="brand" :class="{ claro }">
    <svg :width="tamanho" :height="tamanho" viewBox="0 0 40 40" aria-hidden="true">
      <circle cx="20" cy="20" r="17" fill="none" stroke="currentColor" stroke-opacity=".35" stroke-width="1.2" />
      <circle cx="20" cy="20" r="12.5" fill="none" stroke="currentColor" stroke-opacity=".2" stroke-width="1" stroke-dasharray="1.5 2.5" />
      <path d="M20 2l3.2 15.5L20 20l-3.2-2.5z" fill="var(--teal-400)" />
      <path d="M20 38l-3.2-15.5L20 20l3.2 2.5z" fill="var(--teal-600)" />
      <path d="M2 20l15.5-3.2L20 20l-2.5 3.2z" fill="currentColor" fill-opacity=".85" />
      <path d="M38 20l-15.5 3.2L20 20l2.5-3.2z" fill="currentColor" fill-opacity=".55" />
      <path d="M8 8l10 9-1 1zM32 32l-10-9 1-1zM32 8l-9 10-1-1zM8 32l9-10 1 1z" fill="currentColor" fill-opacity=".3" />
      <circle cx="20" cy="20" r="2" fill="var(--sand-500)" />
    </svg>
    <div v-if="comTexto" class="txt">
      <span class="jornal">JORNAL</span>
      <span class="porto">Porto do Pecém</span>
    </div>
  </div>
</template>

<style scoped>
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  color: var(--navy-900);
}
.brand.claro {
  color: #fff;
}
.txt {
  display: flex;
  flex-direction: column;
  line-height: 1.05;
}
.jornal {
  font-weight: 700;
  font-size: 1.05rem;
  letter-spacing: 0.06em;
  color: var(--teal-500);
}
.claro .jornal {
  color: var(--teal-400);
}
.porto {
  font-size: 0.8rem;
  opacity: 0.85;
}
</style>
