<script setup lang="ts">
import { X } from 'lucide-vue-next'
import { onBeforeUnmount, onMounted } from 'vue'

defineProps<{ titulo: string; largura?: string }>()
const emit = defineEmits<{ fechar: [] }>()

const esc = (e: KeyboardEvent) => e.key === 'Escape' && emit('fechar')
onMounted(() => window.addEventListener('keydown', esc))
onBeforeUnmount(() => window.removeEventListener('keydown', esc))
</script>

<template>
  <Teleport to="body">
    <div class="overlay" @mousedown.self="emit('fechar')">
      <div class="modal" role="dialog" aria-modal="true" :aria-label="titulo" :style="{ maxWidth: largura ?? '520px' }">
        <header>
          <h2>{{ titulo }}</h2>
          <button class="btn btn-ghost btn-icon" aria-label="Fechar" @click="emit('fechar')"><X /></button>
        </header>
        <div class="corpo"><slot /></div>
        <footer v-if="$slots.rodape"><slot name="rodape" /></footer>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  background: rgba(11, 20, 48, 0.55);
  display: grid;
  place-items: center;
  padding: 16px;
  z-index: 90;
  animation: fade 0.15s;
}
.modal {
  width: 100%;
  max-height: calc(100vh - 32px);
  overflow: auto;
  background: var(--surface);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-lg);
}
header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border);
}
header h2 {
  font-size: var(--fs-lg);
}
header .btn {
  border: none;
}
.corpo {
  padding: 20px;
  display: grid;
  gap: 16px;
}
footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 14px 20px;
  border-top: 1px solid var(--border);
  background: var(--surface-sunken);
}
@keyframes fade { from { opacity: 0; } }
</style>
