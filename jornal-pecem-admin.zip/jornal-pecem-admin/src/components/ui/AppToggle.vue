<script setup lang="ts">
const modelo = defineModel<boolean>({ required: true })
defineProps<{ rotulo?: string }>()
</script>

<template>
  <label class="tg">
    <input v-model="modelo" type="checkbox" class="sr-only" />
    <span class="trilho" aria-hidden="true"><span class="bola" /></span>
    <span v-if="rotulo">{{ rotulo }}</span>
  </label>
</template>

<style scoped>
.tg { display: inline-flex; align-items: center; gap: 10px; cursor: pointer; font-size: var(--fs-sm); }
.trilho { width: 36px; height: 20px; border-radius: 999px; background: var(--ink-300); position: relative; transition: background 0.15s; flex: none; }
.bola { position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 50%; background: #fff; box-shadow: var(--shadow-sm); transition: transform 0.15s; }
input:checked + .trilho { background: var(--accent); }
input:checked + .trilho .bola { transform: translateX(16px); }
input:focus-visible + .trilho { box-shadow: var(--focus); }
</style>
