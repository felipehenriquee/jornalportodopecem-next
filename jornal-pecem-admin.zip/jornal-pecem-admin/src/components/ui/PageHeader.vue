<script setup lang="ts">
defineProps<{ titulo: string; subtitulo?: string; eyebrow?: string }>()
</script>

<template>
  <header class="ph">
    <div>
      <p v-if="eyebrow" class="eyebrow">{{ eyebrow }}</p>
      <h1>{{ titulo }}</h1>
      <p v-if="subtitulo" class="muted sub">{{ subtitulo }}</p>
    </div>
    <div class="acoes"><slot /></div>
  </header>
</template>

<style scoped>
.ph {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--sp-4);
  flex-wrap: wrap;
  margin-bottom: var(--sp-5);
}
h1 {
  font-size: var(--fs-xl);
  letter-spacing: -0.01em;
}
.sub {
  margin: 4px 0 0;
  font-size: var(--fs-sm);
}
.acoes {
  display: flex;
  gap: var(--sp-2);
  flex-wrap: wrap;
}
</style>
