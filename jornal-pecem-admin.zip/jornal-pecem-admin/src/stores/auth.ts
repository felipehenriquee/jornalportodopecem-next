import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { authApi } from '@/services/api'
import { getToken, setToken } from '@/services/http'
import type { Papel, Usuario } from '@/types'

const USER_KEY = 'jpp.usuario'

function lerUsuario(): Usuario | null {
  try {
    const raw = localStorage.getItem(USER_KEY)
    return raw ? (JSON.parse(raw) as Usuario) : null
  } catch {
    return null
  }
}

export const useAuthStore = defineStore('auth', () => {
  const usuario = ref<Usuario | null>(getToken() ? lerUsuario() : null)
  const logado = computed(() => !!usuario.value)

  async function entrar(email: string, senha: string) {
    const r = await authApi.login(email, senha)
    setToken(r.token)
    usuario.value = r.usuario
    try {
      localStorage.setItem(USER_KEY, JSON.stringify(r.usuario))
    } catch {
      /* ignora */
    }
  }

  function sair() {
    setToken(null)
    usuario.value = null
    try {
      localStorage.removeItem(USER_KEY)
    } catch {
      /* ignora */
    }
  }

  /** Permissões por papel — ajuste aqui quando a API definir as regras */
  function pode(acao: 'publicar' | 'gerenciarUsuarios' | 'gerenciarAnuncios' | 'gerenciarEditorias') {
    const p: Papel | undefined = usuario.value?.papel
    if (!p) return false
    const regras: Record<typeof acao, Papel[]> = {
      publicar: ['admin', 'editor'],
      gerenciarUsuarios: ['admin'],
      gerenciarAnuncios: ['admin', 'comercial'],
      gerenciarEditorias: ['admin', 'editor'],
    }
    return regras[acao].includes(p)
  }

  return { usuario, logado, entrar, sair, pode }
})
