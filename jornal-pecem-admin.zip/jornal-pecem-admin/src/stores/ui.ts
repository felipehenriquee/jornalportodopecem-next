import { defineStore } from 'pinia'
import { ref, watch } from 'vue'
import { editoriasApi } from '@/services/api'
import type { Editoria } from '@/types'

export interface Toast {
  id: number
  tipo: 'sucesso' | 'erro' | 'info'
  texto: string
}

export const useUiStore = defineStore('ui', () => {
  // Tema
  let salvo: string | null = null
  try {
    salvo = localStorage.getItem('jpp.tema')
  } catch {
    /* ignora */
  }
  const tema = ref<'claro' | 'escuro'>(salvo === 'escuro' ? 'escuro' : 'claro')
  watch(
    tema,
    (t) => {
      document.documentElement.dataset.theme = t === 'escuro' ? 'dark' : 'light'
      try {
        localStorage.setItem('jpp.tema', t)
      } catch {
        /* ignora */
      }
    },
    { immediate: true },
  )

  const sidebarAberta = ref(false)

  // Toasts
  const toasts = ref<Toast[]>([])
  let seq = 0
  function notificar(texto: string, tipo: Toast['tipo'] = 'sucesso') {
    const id = ++seq
    toasts.value.push({ id, tipo, texto })
    setTimeout(() => (toasts.value = toasts.value.filter((t) => t.id !== id)), 3800)
  }

  // Cache de editorias (usadas em vários formulários e filtros)
  const editorias = ref<Editoria[]>([])
  async function carregarEditorias(forcar = false) {
    if (editorias.value.length && !forcar) return
    editorias.value = await editoriasApi.listar()
  }
  const nomeEditoria = (id: number) => editorias.value.find((e) => e.id === id)?.nome ?? '—'
  const corEditoria = (id: number) => editorias.value.find((e) => e.id === id)?.cor ?? 'var(--ink-400)'

  return { tema, sidebarAberta, toasts, notificar, editorias, carregarEditorias, nomeEditoria, corEditoria }
})
