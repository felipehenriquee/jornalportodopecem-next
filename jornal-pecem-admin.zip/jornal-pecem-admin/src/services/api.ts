/**
 * Camada de dados do painel. Cada recurso expõe a mesma interface,
 * seja falando com a API REST (VITE_API_URL) ou com os mocks em memória.
 *
 * Contrato REST esperado (documentado em docs/API.md):
 *   GET    /noticias?busca=&status=&editoriaId=&pagina=&porPagina=
 *   GET    /noticias/:id
 *   POST   /noticias            PUT /noticias/:id     DELETE /noticias/:id
 *   GET    /editorias           POST/PUT/DELETE /editorias/:id
 *   GET    /anuncios            POST/PUT/DELETE /anuncios/:id
 *   GET    /usuarios            POST/PUT /usuarios/:id
 *   GET    /midias              DELETE /midias/:id
 *   POST   /auth/login  { email, senha } → { token, usuario }
 */
import * as mock from '@/data/mock'
import type { Anuncio, Editoria, FiltroNoticias, Midia, Noticia, Paginado, Usuario } from '@/types'
import { espera, http, usandoMock } from './http'

const clone = <T>(v: T): T => structuredClone(v)

// Estado em memória do modo mock (some ao recarregar a página)
const db = {
  noticias: clone(mock.noticias),
  editorias: clone(mock.editorias),
  anuncios: clone(mock.anuncios),
  usuarios: clone(mock.usuarios),
  midias: clone(mock.midias),
}

const proximoId = (lista: { id: number }[]) => Math.max(0, ...lista.map((i) => i.id)) + 1

function crudMock<T extends { id: number }>(chave: 'editorias' | 'anuncios' | 'usuarios' | 'midias') {
  const lista = () => db[chave] as unknown as T[]
  return {
    async listar(): Promise<T[]> {
      await espera()
      return clone(lista())
    },
    async salvar(item: Omit<T, 'id'> & { id?: number }): Promise<T> {
      await espera()
      const l = lista()
      if (item.id) {
        const i = l.findIndex((x) => x.id === item.id)
        l[i] = { ...l[i], ...item } as T
        return clone(l[i])
      }
      const novo = { ...item, id: proximoId(l) } as T
      l.unshift(novo)
      return clone(novo)
    },
    async remover(id: number): Promise<void> {
      await espera()
      const l = lista()
      l.splice(
        l.findIndex((x) => x.id === id),
        1,
      )
    },
  }
}

function crudRest<T extends { id: number }>(recurso: string) {
  return {
    listar: () => http<T[]>(`/${recurso}`),
    salvar: (item: Omit<T, 'id'> & { id?: number }) =>
      item.id
        ? http<T>(`/${recurso}/${item.id}`, { method: 'PUT', body: JSON.stringify(item) })
        : http<T>(`/${recurso}`, { method: 'POST', body: JSON.stringify(item) }),
    remover: (id: number) => http<void>(`/${recurso}/${id}`, { method: 'DELETE' }),
  }
}

const crud = <T extends { id: number }>(r: 'editorias' | 'anuncios' | 'usuarios' | 'midias') =>
  usandoMock ? crudMock<T>(r) : crudRest<T>(r)

export const editoriasApi = crud<Editoria>('editorias')
export const anunciosApi = crud<Anuncio>('anuncios')
export const usuariosApi = crud<Usuario>('usuarios')
export const midiasApi = crud<Midia>('midias')

export const noticiasApi = {
  async listar(f: FiltroNoticias = {}): Promise<Paginado<Noticia>> {
    const pagina = f.pagina ?? 1
    const porPagina = f.porPagina ?? 10
    if (!usandoMock) {
      const q = new URLSearchParams()
      Object.entries({ ...f, pagina, porPagina }).forEach(([k, v]) => {
        if (v !== undefined && v !== '') q.set(k, String(v))
      })
      return http(`/noticias?${q}`)
    }
    await espera()
    const termo = f.busca?.trim().toLowerCase()
    const filtradas = db.noticias
      .filter((n) => !f.status || n.status === f.status)
      .filter((n) => !f.editoriaId || n.editoriaId === f.editoriaId)
      .filter((n) => !termo || n.titulo.toLowerCase().includes(termo) || n.tags.some((t) => t.includes(termo)))
      .sort((a, b) => b.atualizadaEm.localeCompare(a.atualizadaEm))
    return {
      itens: clone(filtradas.slice((pagina - 1) * porPagina, pagina * porPagina)),
      total: filtradas.length,
      pagina,
      porPagina,
    }
  },

  async obter(id: number): Promise<Noticia> {
    if (!usandoMock) return http(`/noticias/${id}`)
    await espera()
    const n = db.noticias.find((x) => x.id === id)
    if (!n) throw new Error('Notícia não encontrada')
    return clone(n)
  },

  async salvar(n: Noticia): Promise<Noticia> {
    const dados = { ...n, atualizadaEm: new Date().toISOString() }
    if (dados.status === 'publicada' && !dados.publicadaEm) dados.publicadaEm = dados.atualizadaEm
    if (!usandoMock) {
      return n.id
        ? http(`/noticias/${n.id}`, { method: 'PUT', body: JSON.stringify(dados) })
        : http('/noticias', { method: 'POST', body: JSON.stringify(dados) })
    }
    await espera(400)
    if (n.id) {
      const i = db.noticias.findIndex((x) => x.id === n.id)
      db.noticias[i] = dados
    } else {
      dados.id = proximoId(db.noticias)
      db.noticias.unshift(dados)
    }
    return clone(dados)
  },

  async remover(id: number): Promise<void> {
    if (!usandoMock) return http(`/noticias/${id}`, { method: 'DELETE' })
    await espera()
    db.noticias = db.noticias.filter((n) => n.id !== id)
  },

  /** Resumo para o painel inicial */
  async resumo() {
    if (!usandoMock) return http<ResumoPainel>('/painel/resumo')
    await espera()
    const conta = (s: Noticia['status']) => db.noticias.filter((n) => n.status === s).length
    return {
      publicadas: conta('publicada'),
      revisao: conta('revisao'),
      agendadas: conta('agendada'),
      rascunhos: conta('rascunho'),
      anunciosAtivos: db.anuncios.filter((a) => a.ativo).length,
      visualizacoes14d: clone(mock.visualizacoesDiarias),
      maisLidas: clone(
        [...db.noticias].filter((n) => n.status === 'publicada').sort((a, b) => b.visualizacoes - a.visualizacoes).slice(0, 5),
      ),
    } satisfies ResumoPainel
  },
}

export interface ResumoPainel {
  publicadas: number
  revisao: number
  agendadas: number
  rascunhos: number
  anunciosAtivos: number
  visualizacoes14d: number[]
  maisLidas: Noticia[]
}

export const authApi = {
  async login(email: string, senha: string): Promise<{ token: string; usuario: Usuario }> {
    if (!usandoMock) return http('/auth/login', { method: 'POST', body: JSON.stringify({ email, senha }) })
    await espera(500)
    const usuario = db.usuarios.find((u) => u.email === email.trim().toLowerCase() && u.ativo)
    // Modo demonstração: qualquer senha com 4+ caracteres para um usuário ativo
    if (!usuario || senha.length < 4) throw new Error('E-mail ou senha inválidos')
    return { token: `mock-${usuario.id}`, usuario: clone(usuario) }
  },
}
