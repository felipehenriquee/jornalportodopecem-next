/**
 * Cliente HTTP mínimo. Quando VITE_API_URL estiver definido, os services
 * chamam a API real; caso contrário usam o adaptador em memória (mock).
 */
export const API_URL = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, '') ?? ''
export const usandoMock = !API_URL

const TOKEN_KEY = 'jpp.token'

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY)
  } catch {
    return null
  }
}

export function setToken(token: string | null) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token)
    else localStorage.removeItem(TOKEN_KEY)
  } catch {
    /* storage indisponível */
  }
}

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message)
  }
}

export async function http<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken()
  const res = await fetch(`${API_URL}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...init.headers,
    },
  })
  if (!res.ok) {
    const msg = await res.text().catch(() => res.statusText)
    throw new HttpError(res.status, msg || res.statusText)
  }
  if (res.status === 204) return undefined as T
  return (await res.json()) as T
}

/** Simula latência de rede nos mocks para os estados de loading aparecerem */
export const espera = (ms = 250) => new Promise((r) => setTimeout(r, ms))
